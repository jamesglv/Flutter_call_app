import UIKit
import Flutter
//import TwilioVoice
//import PushKit
//import CallKit


@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate {
  override func application(
    _ application: UIApplication,
    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
  ) -> Bool {
      
    //NEW CODE START
//
//      let accessToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImN0eSI6InR3aWxpby1mcGE7dj0xIn0.eyJqdGkiOiJTSzQyNjgwYjg1MzgzOGMxOGJkZDIzNDQ4MDgxNDhlNDBmLTE2Njk1MzMzNTUiLCJncmFudHMiOnsiaWRlbnRpdHkiOiJhbGljZSIsInZvaWNlIjp7ImluY29taW5nIjp7ImFsbG93Ijp0cnVlfSwib3V0Z29pbmciOnsiYXBwbGljYXRpb25fc2lkIjoiQVA1NDI3ZTM3ZDQxNWY2YjhkYTg0M2Y1ODFkYmYxMGIxNyJ9LCJwdXNoX2NyZWRlbnRpYWxfc2lkIjoiQ1JjMGYzMGUzMTQ0NjA0YmEzN2M4MmE1OTNhOWE4OGI5YyJ9fSwiaWF0IjoxNjY5NTMzMzU1LCJleHAiOjE2Njk1MzY5NTUsImlzcyI6IlNLNDI2ODBiODUzODM4YzE4YmRkMjM0NDgwODE0OGU0MGYiLCJzdWIiOiJBQzkxNjFlMmI2NGM0YWE4YzBkMjRiOGE2NmZjYjA4MWI1In0.MqF0uA5Q2FIhF90F6ZaGzZOrGE1KW5oDtOwT_Sa8g-c"
//      let twimlParamTo = "to"
//
//      let kCachedDeviceToken = "CachedDeviceToken"
//      
//      TwilioVoiceSDK.register(accessToken: accessToken, deviceToken: cachedDeviceToken) { error in
//          if let error = error {
//              NSLog("An error occurred while registering: \(error.localizedDescription)")
//          } else {
//              NSLog("Successfully registered for VoIP push notifications.")
//          }
//      }

      
    //NEW CODE END
      
    GeneratedPluginRegistrant.register(with: self)
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}
