const { database } = require("firebase-admin");
const admin = require("firebase-admin");
const functions = require("firebase-functions");
admin.initializeApp();

//CALLING
//const { AccessToken } = require('twilio').jwt;
//const { VoiceGrant } = AccessToken;
//const twimlSid = "APfcd4ccad60f793be21cb38fe28b1fb2c";
//const TwilioAPISID = 'SKb18e2bed33cce2b50a9bad1cb363e790';
//const TwilioAPISecret = 'u1u2JyDTQUtYBktdSl2J4GwtsJBEWM9z';

// Securely pass JWT token so users can connect to Twilio call
//exports.twilioTokenHandler = functions.https.onCall((uid, roomName) => {
//    const AccessToken = Twilio.jwt.AccessToken;
//    const VideoGrant = AccessToken.VideoGrant;
//    const twilioAccountSid = functions.config().twilio_api.account_sid;
//    const twilioApiKey = functions.config().twilio_api.key;
//    const twilioApiSecret = functions.config().twilio_api.secret;
//    const token = new AccessToken(twilioAccountSid, twilioApiKey, twilioApiSecret);
//    token.identity = uid;
//
//    const videoGrant = new VideoGrant({ room: roomName});
//
//    token.addGrant(videoGrant);
//
//    console.log("Sending token: ", token);
//    return {
//      token: token.toJwt()
//    }
//});

const { AccessToken } = require('twilio').jwt;

const { VoiceGrant } = AccessToken;

exports.accessToken = functions
  .runWith({ secrets: ["TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN"] })
  .https.onCall((context, event, callback) => {
  const accountSid = process.env.TWILIO_ACCOUNT_SID;
  const twilioApiKey = 'SK5a399a6ec572e88f2410439496d99db9';
  const TwilioApiSecret = 'u1u2JyDTQUtYBktdSl2J4GwtsJBEWM9z';
  const identity = event.identity;

//Access token
  const AccessToken = Twilio.jwt.AccessToken;

    const token = new AccessToken(
      twilioAccountSid,
      twilioApiKey,
      twilioApiSecret,
      {identity: identity}
    );

//Add voice grant
    const VoiceGrant = AccessToken.VoiceGrant;

    const voiceGrant = new VoiceGrant({
      outgoingApplicationSid: 'AP9779a7c181bb9ca77ed6f11c812124f9',
      incomingAllow: true // allows your client-side device to receive calls as well as make them
    });

    token.addGrant(voiceGrant);

//Generate response
    const response = new Twilio.Response();
      const headers = {
        "Access-Control-Allow-Origin": "*", // change this to your client-side URL
        "Access-Control-Allow-Methods": "GET,PUT,POST,DELETE,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
        "Content-Type": "application/json"
      };

      response.setHeaders(headers);
      response.setBody({
        accessToken: token.toJwt()
      });

      return callback(null, response);
});

exports.twilioCreateSubAccount = functions
  .runWith({ secrets: ["TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN"] })
  .https.onCall(async (data, context) => {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const client = require("twilio")(accountSid, authToken);

    try {
      const subAccountSid = await client.api.v2010.accounts
        .create({ friendlyName: data.friendlyName })
        .then((account) => {
          console.log(account.sid);
          return account.sid;
        });

      return {
        status: "OK",
        data: { subAccountSid: subAccountSid },
        errors: null,
      };
    } catch (e) {
      console.log("error caught: ", e);
      return {
        status: "ERROR",
        data: null,
        errors: e,
      };
    }
  });

exports.twilioIncomingPhoneNumber = functions
  .runWith({ secrets: ["TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN"] })
  .https.onCall(async (data, context) => {
    const bundleSid = "BU051a71986424b619051ca9eafbd03051";
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const twilioClient = require("twilio")(accountSid, authToken);
    console.log("client successfully created");
    try {
      const result = await twilioClient.incomingPhoneNumbers
        .create({
          addressSid: "AD84244a7d38df9d23891636d53fa56221",
          bundleSid: bundleSid,
          phoneNumber: data.phoneNumber,
        })
        .then((incoming_phone_number) => {
          console.log("sid of new number: ", incoming_phone_number.sid);
          return incoming_phone_number;
        });

      return {
        status: "OK",
        data: {
          friendly_name: result.friendlyName,
          phone_number: result.phoneNumber,
          sid: result.sid,
          sms_url: result.smsUrl,
          status: result.status,
          uri: result.uri,
        },
        errors: null,
      };
    } catch (e) {
      console.log("error caught: ", e);
      return {
        status: "ERROR",
        data: null,
        errors: e,
      };
    }
  });

exports.twilioGetAvailableNumbers = functions
  .runWith({ secrets: ["TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN"] })
  .https.onCall(async (data, context) => {
    const accountSid = process.env.TWILIO_ACCOUNT_SID;
    const authToken = process.env.TWILIO_AUTH_TOKEN;
    const twilioClient = require("twilio")(accountSid, authToken);
    try {
      const availableNumbers = [];
      await twilioClient
        .availablePhoneNumbers("AU")
        .mobile.list({ smsEnabled: true, limit: 30 })
        .then((numbers) => {
          numbers.forEach((mobile) => {
            console.log(mobile.friendlyName);
            console.log("sms: ", mobile.capabilities.sms);
            availableNumbers.push({
              accountSid: mobile.accountSid,
              addressSid: mobile.addressSid,
              friendlyName: mobile.friendlyName,
              mobile: mobile.phoneNumber,
              sms: mobile.capabilities.sms,
              voice: mobile.capabilities.voice,
            });
          });
          return numbers;
        });

      return {
        status: "OK",
        data: availableNumbers,
        errors: null,
      };
    } catch (e) {
      console.log("Error caught", e);
      return {
        status: "ERROR",
        data: null,
        errors: e,
      };
    }
  });

exports.twilioSMSListener = functions.https.onRequest(
  async (request, response) => {
    console.log("twilio webhook inbound (to): ", request.body.To);
    console.log("twilio webhook inbound (from): ", request.body.From);
    console.log("twilio webhook inbound (body): ", request.body.Body);
    const data = request.body;
    const d = new Date();
    const millisecondsSinceEpoch = d.getTime().toString();
    const message = {};
    const smsData = {
      created_at: admin.firestore.Timestamp.now(),
      to: data.To,
      from: data.From,
      body: data.Body,
      sms_message_sid: data.SmsMessageSid,
      sms_sid: data.SmsSid,
      message_sid: data.MessageSid,
      account_sid: data.AccountSid,
      price: 0.0075,
    };
    message[millisecondsSinceEpoch] = smsData;

    // Check if the "To" phone number is in the database.
    const sentToPhoneNumber = await admin
      .firestore()
      .collection("phone_numbers")
      .where("phone_number", "==", smsData.to)
      .limit(1)
      .get();

    // Check if the "From" phone number is already in the database.
    const sentFromPhoneNumber = await admin
      .firestore()
      .collection("phone_numbers")
      .where("phone_number", "==", smsData.from)
      .limit(1)
      .get();

    // If the recipient is an app user and the message is from a non app user then we need to add the message
    // to the database. If the message was sent from the app, then it will have already been added to the database.
    if (
      sentToPhoneNumber.empty === false &&
      sentFromPhoneNumber.empty === true
    ) {
      // Check if a conversation already exists between these two phone numbers.
      const conversations = await admin
        .firestore()
        .collection("conversations")
        .where("members", "array-contains", smsData.to)
        .get();
      // Loop through conversations
      var currentConversationId = null;
      for (var i = 0; i < conversations.docs.length; i++) {
        if (
          conversations.docs[i].data().members.includes(smsData.from) === true
        ) {
          currentConversationId = conversations.docs[i].id;
          break;
        }
      }
      if (currentConversationId !== null) {
        const messagesId = "messages/" + currentConversationId.toString();
        const messagesRef = admin.firestore().doc(messagesId);
        messagesRef.update(message);

        //update conversation information
        const conversationId = "conversations/" + currentConversationId.toString();
        const conversationPath = admin.firestore().doc(conversationId);
        conversationPath.update({
            "last_modified": admin.firestore.Timestamp.now(),
            "last_message": smsData.body,
            "read": false //Set to unread upon receiving message
        });

      } else {
        // Create a Conversation and corresponding Messages Record
        const conversationRef = admin
          .firestore()
          .collection("conversations")
          .doc();
        conversationRef.set({
          created_at: admin.firestore.Timestamp.now(),
          members: [smsData.to, smsData.from],
        });
        // Create the Message
        const newMessageRef = "messages/" + conversationRef.id;
        admin.firestore().doc(newMessageRef).set(message);
        return;
      }
    }
    //TODO Twilio is expecting some type of response. Need to dig as it does not clearly outline this in the docs
    return;
  }
);

exports.twilioSendMessage = functions
  .runWith({ secrets: ["TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN"] })
  .https.onCall(async (data, context) => {
    try {
      //const client = getClient();
      const accountSid = process.env.TWILIO_ACCOUNT_SID;
      const authToken = process.env.TWILIO_AUTH_TOKEN;
      const twilioClient = require("twilio")(accountSid, authToken);
      const result = await twilioClient.messages
        .create({ body: data.body, from: data.from, to: data.to })
        .then((message) => {
          console.log(
            message.sid,
            ", ",
            message.price,
            ", ",
            message.priceUnit
          );
          return message;
        });
      return {
        status: "OK",
        message_sid: result.sid,
        message_price: result.price,
        message_price_unit: result.priceUnit,
        errors: null,
      };
    } catch (e) {
      console.log("error caught: ", e);
      return {
        status: "ERROR",
        message_sid: null,
        message_price: null,
        message_price_unit: null,
        errors: e,
      };
    }
  });

exports.twilioMakeCall = functions
  .runWith({ secrets: ["TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN"] })
  .https.onCall(async (data, context) => {
    try {
      const accountSid = process.env.TWILIO_ACCOUNT_SID;
      const authToken = process.env.TWILIO_AUTH_TOKEN;
      const twilioClient = require("twilio")(accountSid, authToken);
      twilioClient.calls
            .create({
               url: 'http://demo.twilio.com/docs/voice.xml',
               to: data.callTo,
               from: data.callFrom
             })
            .then(call => console.log(call.sid));

      return {
        status: "OK",
        errors: null,
      };
    } catch (e) {
      console.log("error caught: ", e);
      return {
        status: "ERROR",
        errors: e,
      };
    }
  });

/// Retired code for handling Sub Accounts

// exports.twilioBundleCallback = functions.https.onRequest(
//   async (request, response) => {
//     console.log("twilio says: ", request.body);
//   }
// );

// const subAccountAddressSid = await createSubAccountAddress(
//   twilioClient,
//   subAccountSid
// );
// const subAccountBundleSid = await createSubAccountBundle(
//   twilioClient,
//   subAccountSid
// );
// const result = await twilioClient
//   .incomingPhoneNumbers(phoneNumberSid)
//   .update({
//     accountSid: subAccountSid,
//     addressSid: subAccountAddressSid,
//     bundleSid: subAccountBundleSid,
//   })
//   .then((incoming_phone_number) => {
//     console.log(incoming_phone_number.friendlyName);
//     return incoming_phone_number;
//   });

// async function getSubAccountAuthToken(client, subAccountSid) {
//   try {
//     return await client.api.v2010
//       .accounts(subAccountSid)
//       .fetch()
//       .then((account) => {
//         console.log(account.authToken);
//         return account.authToken;
//       });
//   } catch (e) {
//     console.log("error caught: ", e);
//     return null;
//   }
// }

// async function createSubAccountAddress(primaryClient, subAccountSid) {
//   const authToken = await getSubAccountAuthToken(primaryClient, subAccountSid);
//   const secondaryClient = require("twilio")(subAccountSid, authToken);

//   const subAccountAddressSid = await secondaryClient.addresses
//     .create({
//       customerName: "James Ogilview(SubAcct)",
//       street: "3 Boom Ct",
//       city: "Birkdale",
//       region: "QLD",
//       postalCode: "4159",
//       isoCountry: "AU",
//     })
//     .then((address) => {
//       console.log("new subAccount address: ", address.sid);
//       return address.sid;
//     });
//   return subAccountAddressSid;
// }

// async function createSubAccountBundle(primaryClient, subAccountSid) {
//   const authToken = await getSubAccountAuthToken(primaryClient, subAccountSid);
//   const secondaryClient = require("twilio")(subAccountSid, authToken);
//   console.log("bundle secondaryClient successfully created");

//   const subAccountBundleSid =
//     await secondaryClient.numbers.v2.regulatoryCompliance.bundles
//       .create({
//         endUserType: "individual",
//         isoCountry: "au",
//         numberType: "mobile",
//         statusCallback:
//           "https://us-central1-messenger-715ad.cloudfunctions.net/twilioBundleCallback",
//         friendlyName: "subaccount bundle",
//         email: "jamesoglv@gmail.com",
//       })
//       .then((bundle) => {
//         console.log(bundle.sid);
//         return bundle.sid;
//       });
//   return subAccountBundleSid;
// }
