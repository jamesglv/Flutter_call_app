import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

Future<DocumentReference?> getConversation({uid1, uid2}) async {
  DocumentReference? conversationRef = await FirebaseFirestore.instance
      .collection('conversations')
      .where("members", whereIn: [
        [uid1, uid2],
        [uid2, uid1]
      ])
      .get()
      .then((QuerySnapshot<Map<String, dynamic>> result) {
        return result.docs.isNotEmpty ? result.docs.first.reference : null;
      });
  print('uid1: $uid1 || uid2: $uid2');
  print('conversationRef: $conversationRef');
  return conversationRef;
}

Future<String> getCurrentUserNumber() async {
  final usersPhoneNumber = await FirebaseFirestore.instance
      .doc(
      'phone_numbers/${FirebaseAuth.instance.currentUser?.uid}')
      .get()
      .then((value) => value.data()?['phone_number']);
  return usersPhoneNumber;
}

Future<DocumentReference> startNewConversation({uid1, uid2}) async {
  // Create a conversation document
  DocumentReference conversationRef =
      FirebaseFirestore.instance.collection('conversations').doc();
  await conversationRef.set({
    "created_at": DateTime.now(),
    "members": [uid1, uid2],
    "last_modified": DateTime.now(),
    "last_message": ""
  });

  // Create a messages document for the conversation
  await FirebaseFirestore.instance
      .doc('messages/${conversationRef.id}')
      .set({});

  print('new conv: ${conversationRef}');
  return conversationRef;
}
