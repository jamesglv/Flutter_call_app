import 'package:cloud_firestore/cloud_firestore.dart';

String timeAgo(String ts) {
  //sample ts: "2022-04-12T22:28:17+0000"
  String text = ts;
  List initial = text.split("T");
  int year = int.parse(initial[0].split("-")[0]);
  int month = int.parse(initial[0].split("-")[1]);
  int day = int.parse(initial[0].split("-")[2]);
  int hour = int.parse(initial[1].split(":")[0]);
  int minute = int.parse(initial[1].split(":")[1]);
  int second = int.parse(initial[1].split(":")[2].split('+')[0]);
  DateTime _dt = DateTime(year, month, day, hour, minute, second);

  int _daysAgo = DateTime.now().difference(_dt).inDays;

  if (_daysAgo < 7) {
    return "$_daysAgo days";
  } else if (_daysAgo > 30 && _daysAgo < 365) {
    int _months = (_daysAgo / 30).abs().toInt();
    int _days = (_daysAgo % 30).abs().toInt();
    return "${_months} month${_months > 1 ? 's' : ''}";
  } else {
    return "more than 1 year";
  }
}

/// Return a formatted date e.g. "15 November at 01:22pm"
String longFormatDate(Timestamp ts) {
  DateTime date = ts.toDate();
  String day = date.day < 10 ? timeHelper[date.day] : date.day.toString();
  String month = monthHelperLong[date.month];
  String minute =
      date.minute < 10 ? timeHelper[date.minute] : date.minute.toString();
  String hour = timeHelper[date.hour];
  return "$day $month at $hour:$minute ${date.hour > 11 ? "pm" : "am"}";
}

/// Return a formatted time e.g. "01:22pm"
String startAndEndTime(Timestamp st, Timestamp et) {
  DateTime startDateTime = st.toDate();
  String day = startDateTime.day < 10
      ? timeHelper[startDateTime.day]
      : startDateTime.day.toString();
  String month = monthHelper[startDateTime.month];

  String start = HHMM(st);
  String end = HHMM(et);

  return "$day-$month ($start to $end)";
}

/// Return a formatted date e.g. "12-May"
String DDMM(Timestamp ts) {
  DateTime date = ts.toDate();
  String day = date.day < 10 ? timeHelper[date.day] : date.day.toString();
  String month = monthHelper[date.month];
  return "$day-$month";
}

/// Return a formatted time e.g. "01:22pm"
String HHMM(Timestamp ts) {
  DateTime date = ts.toDate();
  String minute =
      date.minute < 10 ? timeHelper[date.minute] : date.minute.toString();
  String hour = timeHelper[date.hour];
  return "$hour:$minute ${date.hour > 11 ? "pm" : "am"}";
}

String dayOfWeek(int dayToCheck){
  if (dayToCheck == 1) {
    return "Monday";
  } else if (dayToCheck == 2) {
    return "Tuesday";
  } else if (dayToCheck == 3) {
    return "Wednesday";
  } else if (dayToCheck == 4) {
    return "Thursday";
  } else if (dayToCheck == 5) {
    return "Friday";
  } else if (dayToCheck == 6) {
    return "Saturday";
  } else if (dayToCheck == 7) {
    return "Sunday";
  } else { return "null";}
}

/// Return a formatted time e.g. "01:22pm", "Yesterday" or a day of week if earlier "Monday"
String messageFormatDate(Timestamp ts) {
  DateTime date = ts.toDate();

  var now = DateTime.now();
  var today = DateTime(now.year, now.month, now.day);
  var yesterday = DateTime(now.year, now.month, now.day - 1);
  var thisWeek = DateTime(now.year, now.month, now.day - 6);

  final dateToCheck = date;
  final aDate = DateTime(dateToCheck.year, dateToCheck.month, dateToCheck.day);
  if(aDate == today) {
    String minute =
    date.minute < 10 ? timeHelper[date.minute] : date.minute.toString();
    String hour = timeHelper[date.hour];
    return "$hour:$minute ${date.hour > 11 ? "pm" : "am"}";

  } else if (aDate == yesterday) {
    return "Yesterday";

  } else if ( thisWeek.millisecondsSinceEpoch < aDate.millisecondsSinceEpoch
      && aDate.millisecondsSinceEpoch < yesterday.millisecondsSinceEpoch) {
    return dayOfWeek(dateToCheck.weekday);
  } else {
    return '${DDMM(ts)}';
  }


}

bool futureEvent(Timestamp ts) {
  DateTime dt = ts.toDate();
  print('event dt: ${ts.toDate()}');
  print('event ts is after now: ${dt.isAfter(DateTime.now())}');
  return dt.isAfter(DateTime.now());
}

Map timeHelper = {
  0: "00",
  1: "01",
  2: "02",
  3: "03",
  4: "04",
  5: "05",
  6: "06",
  7: "07",
  8: "08",
  9: "09",
  10: "10",
  11: "11",
  12: "12",
  13: "01",
  14: "02",
  15: "03",
  16: "04",
  17: "05",
  18: "06",
  19: "07",
  20: "08",
  21: "09",
  22: "10",
  23: "11"
};

Map monthHelper = {
  1: "Jan",
  2: "Feb",
  3: "Mar",
  4: "Apr",
  5: "May",
  6: "Jun",
  7: "Jul",
  8: "Aug",
  9: "Sep",
  10: "Oct",
  11: "Nov",
  12: "Dec"
};

Map monthHelperLong = {
  1: "January",
  2: "February",
  3: "March",
  4: "April",
  5: "May",
  6: "June",
  7: "July",
  8: "August",
  9: "September",
  10: "October",
  11: "November",
  12: "December"
};
