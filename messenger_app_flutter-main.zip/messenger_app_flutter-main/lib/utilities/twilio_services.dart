import 'dart:async';
import 'dart:convert' as convert;
import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:http/http.dart' as http;
import 'package:messenger_app_flutter/utilities/firestore_services.dart';

Future<Map> assignPhoneNumber({required String phoneNumber}) async {
  HttpsCallable callable = FirebaseFunctions.instance.httpsCallable(
      'twilioIncomingPhoneNumber',
      options: HttpsCallableOptions(timeout: Duration(seconds: 30)));
  final HttpsCallableResult _result = await callable.call(<String, String>{
    'subAccountSid': "AC269144d18346ca9df8e7bafcc2de1163",
    'phoneNumber': phoneNumber
  });

  if (_result.data['status'] == 'OK') {
    Map _mapResult = _result.data as Map;
    return _mapResult['data'];
  } else {
    print('Request failed: ${_result.data}.');
    return {};
  }
}

Future<List> getAvailableNumbers() async {
  HttpsCallable callable = FirebaseFunctions.instance.httpsCallable(
      'twilioGetAvailableNumbers',
      options: HttpsCallableOptions(timeout: Duration(seconds: 30)));
  final HttpsCallableResult _result = await callable.call();

  if (_result.data['status'] == 'OK') {
    print('_result.data[data]: ${_result.data['data']}');
    return _result.data['data'];
  } else {
    print('Request failed: ${_result.data}.');
    return [];
  }
}


//Just added line 49. Fix cloud funtion to take in parameters callTo and callFrom. Then test with real numbers.
Future<List> makeCall({required String callTo, required String callFrom}) async {
  HttpsCallable callable = FirebaseFunctions.instance.httpsCallable(
      'twilioMakeCall',
      options: HttpsCallableOptions(timeout: Duration(seconds: 30)));
  final HttpsCallableResult callResult = await callable.call(<String, String>{'callTo': callTo, 'callFrom': callFrom});

  if (callResult.data['status'] == 'OK') {
    //print('_result.data[data]: ${callResult.data}');
    return callResult.data['data'] ?? "null";
  } else {
    print('Request failed: ${callResult.data}.');
    return [];
  }
}

Future<DocumentSnapshot<Map<String, dynamic>>?> getCurrentConversation(
    to, from) async {
  // Check if a conversation already exists between these two phone numbers.
  QuerySnapshot<Map<String, dynamic>> conversations = await FirebaseFirestore
      .instance
      .collection("conversations")
      .where("members", arrayContains: to)
      .get();
  // Loop through conversations
  DocumentSnapshot<Map<String, dynamic>>? currentConversation;
  for (var i = 0; i < conversations.docs.length; i++) {
    if (conversations.docs[i].data()['members'].contains(from) == true) {
      currentConversation = conversations.docs[i];
      break;
    }
  }
  return currentConversation;
}

///Set conversation to read for notifications
Future<DocumentReference<Map<String, dynamic>>?> setConversationToRead(
    to, from) async {
      DocumentSnapshot<Map<String, dynamic>>? currentConversation =
      await getCurrentConversation(to, from);
      if (currentConversation != null) {
        //Update Conversation
        String conversationId = "conversations/" + currentConversation.id;
        DocumentReference<Map<String, dynamic>> conversationRef =
        FirebaseFirestore.instance.doc(conversationId);
        conversationRef.update({
          "read": true // set to read, given message is outbound
        });
      }
  }

Future<DocumentReference<Map<String, dynamic>>?> addMessageToDatabase(
    message) async {
  DocumentSnapshot<Map<String, dynamic>>? currentConversation =
      await getCurrentConversation(message['to'], message['from']);
  if (currentConversation != null) {
    String messagesId = "messages/" + currentConversation.id;
    DocumentReference<Map<String, dynamic>> messagesRef =
        FirebaseFirestore.instance.doc(messagesId);
    messagesRef.update({"${DateTime.now().millisecondsSinceEpoch}": message});

    //Update Conversation
    String conversationId = "conversations/" + currentConversation.id;
    DocumentReference<Map<String, dynamic>> conversationRef =
      FirebaseFirestore.instance.doc(conversationId);
    conversationRef.update({
      "last_modified": DateTime.now(),
      "last_message" : message['body'],
      "read": true
    });

    //Update Billing
    // FirebaseFirestore.instance
    //     .collection('billing')
    //     .doc(FirebaseAuth.instance.currentUser?.uid)
    //     .update({
    //       'region': "AU",
    //       'November2022': "0.05"
    // });

    return messagesRef;
  } else {
    // Create a Conversation and corresponding Messages Record
    print('members: ${[message['to'], message['from']]}');
    DocumentReference conversationRef =
        FirebaseFirestore.instance.collection("conversations").doc();
    conversationRef.update({
      "created_at": DateTime.now(),
      "members": [message['to'], message['from']],
      "last_modified": DateTime.now(),
      "last_message": message['body']
    });
    // Create the Message
    String newMessagesAddress = "messages/" + conversationRef.id;
    DocumentReference<Map<String, dynamic>> newMessagesRef =
        FirebaseFirestore.instance.doc(newMessagesAddress);

    await newMessagesRef
        .set({"${DateTime.now().millisecondsSinceEpoch}": message});
    return newMessagesRef;
  }
}

///Archived Sub Account Code
// Future<Map> setupSubAccount({required String friendlyName}) async {
//   HttpsCallable callable = FirebaseFunctions.instance.httpsCallable(
//       'twilioCreateSubAccount',
//       options: HttpsCallableOptions(timeout: Duration(seconds: 30)));
//   final HttpsCallableResult _result =
//       await callable.call(<String, String>{'friendlyName': friendlyName});
//
//   if (_result.data['status'] == 'OK') {
//     print('_result.data[data]: ${_result.data['data']}');
//     return _result.data['data'];
//   } else {
//     print('Request failed: ${_result.data}.');
//     return {};
//   }
// }
