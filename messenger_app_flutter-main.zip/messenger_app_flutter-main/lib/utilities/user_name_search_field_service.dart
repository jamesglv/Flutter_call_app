List<String> createUserNameSearchField({required String userName}) {
  List<String> _userNameSearchArray = [];

  for (var i = 1; i <= userName.length; i++) {
    _userNameSearchArray.add(userName.substring(0, i).toLowerCase());

    ///If no users exist, display the text input (number to search for)
    // if (_userNameSearchArray.isEmpty) {
    //   _userNameSearchArray.add(userName.substring(0, i));
    // }
  }
  return _userNameSearchArray;
}
