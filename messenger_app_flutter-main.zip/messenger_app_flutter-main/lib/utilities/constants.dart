import 'package:flutter/material.dart';

///

AppBar kCommonAppBar({@required context}) => AppBar(
      leading: IconButton(
        icon: Icon(Icons.menu),
        onPressed: () {
          Navigator.push(
              context, MaterialPageRoute(builder: (context) => Placeholder()));
        },
      ),
      centerTitle: true,
      title: Text(
        'Messenger',
        style: kP1.copyWith(color: Colors.blue),
      ),
      actions: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Image.asset('assets/images/messenger_logo.png'),
        )
      ],
      elevation: 5,
      flexibleSpace: Container(
        decoration: BoxDecoration(
            color: Colors.white, boxShadow: [BoxShadow(blurRadius: 4)]),
      ),
    );

LinearGradient kDdGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: <Color>[Color(0xFF493AFC), Color(0xFF5E2FE4)],
);

LinearGradient kThemeGradient = LinearGradient(
  begin: Alignment.topLeft,
  end: Alignment.bottomRight,
  colors: <Color>[Color(0xFF7C51F4), Color(0xFF11FBBC)],
);

const MaterialColor kThemeColor = MaterialColor(
  0xFF3b4484,
  <int, Color>{
    50: Color(0XFFFDF1CD),
    100: Color(0XFFDC7B76),
    200: Color(0xFF0C0068),
    300: Color(0xFF0C0068),
    400: Color(0xFF0C0068),
    500: Color(0xFF6AA4B0),
    600: Color(0xFF6AA4B0),
    700: Color(0xFF57828B),
    800: Color(0xFF4A676D),
    900: Color(0xFF1c1c1c),
  },
);

double kLeftMargin = 15.0;

ButtonStyle defaultButtonStyle = ElevatedButton.styleFrom(
    primary: Colors.blueAccent.shade700,
    textStyle: kP1White,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)));

ButtonStyle greenButtonStyle = ElevatedButton.styleFrom(
    primary: Colors.green, onPrimary: Colors.white, textStyle: kP1);

ButtonStyle whiteButtonStyle = ElevatedButton.styleFrom(
    primary: Colors.white, onPrimary: kThemeColor[200], textStyle: kP1);

const TextStyle kH1 =
    TextStyle(fontFamily: 'Manrope', fontSize: 24, color: Colors.black);
const TextStyle kH2 =
    TextStyle(fontFamily: 'Manrope', fontSize: 22, color: Colors.black);
const TextStyle kH3 =
    TextStyle(fontFamily: 'Manrope', fontSize: 20, color: Colors.black);
const TextStyle kH4 =
    TextStyle(fontFamily: 'Manrope', fontSize: 18, color: Colors.black);

const TextStyle kH1White =
    TextStyle(fontFamily: 'Manrope', fontSize: 24, color: Colors.white);
const TextStyle kH2White =
    TextStyle(fontFamily: 'Manrope', fontSize: 22, color: Colors.white);
const TextStyle kH3White =
    TextStyle(fontFamily: 'Manrope', fontSize: 20, color: Colors.white);
const TextStyle kH4White =
    TextStyle(fontFamily: 'Manrope', fontSize: 18, color: Colors.white);

const TextStyle kH1Bold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 24,
    color: Colors.black);
const TextStyle kH2Bold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 22,
    color: Colors.black);
const TextStyle kH3Bold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 20,
    color: Colors.black);
const TextStyle kH4Bold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 18,
    color: Colors.black);

const TextStyle kH1WhiteBold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 24,
    color: Colors.white);
const TextStyle kH2WhiteBold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 22,
    color: Colors.white);
const TextStyle kH3WhiteBold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 20,
    color: Colors.white);
const TextStyle kH4WhiteBold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 18,
    color: Colors.white);

const TextStyle kP1 =
    TextStyle(fontFamily: 'Manrope', fontSize: 14, color: Colors.black);
const TextStyle kP2 =
    TextStyle(fontFamily: 'Manrope', fontSize: 12, color: Colors.black);
const TextStyle kP3 =
    TextStyle(fontFamily: 'Manrope', fontSize: 10, color: Colors.black);
const TextStyle kP4 =
    TextStyle(fontFamily: 'Manrope', fontSize: 8, color: Colors.black);

const TextStyle kP1White =
    TextStyle(fontFamily: 'Manrope', fontSize: 14, color: Colors.white);
const TextStyle kP2White =
    TextStyle(fontFamily: 'Manrope', fontSize: 12, color: Colors.white);
const TextStyle kP3White =
    TextStyle(fontFamily: 'Manrope', fontSize: 10, color: Colors.white);
const TextStyle kP4White =
    TextStyle(fontFamily: 'Manrope', fontSize: 8, color: Colors.white);

const TextStyle kP1Bold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 14,
    color: Colors.black);
const TextStyle kP2Bold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 12,
    color: Colors.black);
const TextStyle kP3Bold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 10,
    color: Colors.black);
const TextStyle kP4Bold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 8,
    color: Colors.black);

const TextStyle kP1WhiteBold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 14,
    color: Colors.white);
const TextStyle kP2WhiteBold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 12,
    color: Colors.white);
const TextStyle kP3WhiteBold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 10,
    color: Colors.white);
const TextStyle kP4WhiteBold = TextStyle(
    fontFamily: 'Manrope',
    fontWeight: FontWeight.bold,
    fontSize: 8,
    color: Colors.white);
