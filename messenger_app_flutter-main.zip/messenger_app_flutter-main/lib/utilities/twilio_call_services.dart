import 'dart:convert';

import 'package:cloud_functions/cloud_functions.dart';
import 'package:http/http.dart' as http;
import 'package:http/http.dart';

Future<String> getToken() async {

  HttpsCallable callable = FirebaseFunctions.instance.httpsCallable(
      'accessToken',
      options: HttpsCallableOptions(timeout: Duration(seconds: 30)));
  final HttpsCallableResult _result = await callable.call();

  return _result.data;
  /*
  if (_result.data['status'] == 'OK') {
    print('_result.data.token: ');//${_result.data["token"]}');
    return _result.data['token'];
  } else {
    print('Request failed: ');//${_result.data}.');
    return "Failed";
  } */
}

Future<Object> fetchToken() async {
  final response = await http
      .get(Uri.parse('https://token-service-4874-dev.twil.io/token'));

  if (response.statusCode == 200) {
    // If the server did return a 200 OK response,
    // then parse the JSON.
    var tokenObject = jsonDecode(response.body);
    var token = tokenObject['accessToken'];
    return token;
  } else {
    // If the server did not return a 200 OK response,
    // then throw an exception.
    throw Exception('Failed to load album');
  }
}