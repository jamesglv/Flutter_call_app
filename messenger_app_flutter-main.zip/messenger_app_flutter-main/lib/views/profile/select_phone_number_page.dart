import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/utilities/twilio_services.dart';
import 'package:messenger_app_flutter/views/messages/messages_page.dart';

class SelectPhoneNumberPage extends StatefulWidget {
  final DocumentReference? profileRef;

  SelectPhoneNumberPage({this.profileRef});

  @override
  State<SelectPhoneNumberPage> createState() => _SelectPhoneNumberPageState();
}

class _SelectPhoneNumberPageState extends State<SelectPhoneNumberPage> {
  bool waiting = false;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: waiting
            ? Center(
                child: CircularProgressIndicator(),
              )
            : FutureBuilder<List>(
                future: getAvailableNumbers(),
                builder: (context, future) {
                  if (future.connectionState == ConnectionState.waiting)
                    return Center(
                      child: CircularProgressIndicator(),
                    );
                  if (!future.hasData)
                    return Text('No numbers available. Try again later.');
                  List numbers = future.data ?? [];
                  return ListView(
                    children: List.generate(
                        numbers.length,
                        (index) => ListTile(
                              leading: Icon(Icons.phone),
                              title: Text('${numbers[index]['friendlyName']}'),
                              onTap: () async {
                                setState(() {
                                  waiting = true;
                                });

                                /// Assigns the phone number to the primary account
                                Map result = await assignPhoneNumber(
                                    phoneNumber: numbers[index]['mobile']);
                                print('result from assignPhone: $result');

                                /// Verify the user is logged in and create/update the
                                /// the phone number record for this user
                                if (widget.profileRef?.id != null) {
                                  String? currentUser = widget.profileRef?.id;
                                  await FirebaseFirestore.instance
                                      .doc("phone_numbers/$currentUser")
                                      .set({
                                    "friendly_name": result['friendly_name'],
                                    "phone_number": result['phone_number'],
                                    "sid": result['sid'],
                                    "sms_url": result['sms_url'],
                                    "status": result['status'],
                                    "uri": result['uri'],
                                  });
                                  await FirebaseFirestore.instance
                                      .doc("profiles/$currentUser")
                                      .update({
                                    "twilio_number": result['phone_number'],
                                  });
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              MessagesPage()));
                                } else {
                                  //TODO implement error handling to deal with any issues
                                  // that might occur when you try to assign the phone
                                  // number
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                              MessagesPage()));
                                }
                              },
                            )),
                  );
                },
              ),
      ),
    );
  }
}
