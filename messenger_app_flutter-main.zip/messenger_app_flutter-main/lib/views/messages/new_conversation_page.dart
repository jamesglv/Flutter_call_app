import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/default_text_field.dart';
import 'package:messenger_app_flutter/components/message_bubble.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/utilities/twilio_services.dart';

class NewConversationPage extends StatefulWidget {
  final String usersPhoneNumber;
  const NewConversationPage({Key? key, required this.usersPhoneNumber})
      : super(key: key);

  @override
  State<NewConversationPage> createState() => _NewConversationPageState();
}

class _NewConversationPageState extends State<NewConversationPage> {
  DocumentReference<Map<String, dynamic>>? messages;
  String receiversPhoneNumber = "";
  bool receiversPhoneNumberSelected = false;
  TextEditingController phoneNumberController = TextEditingController();
  TextEditingController messageController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text("New Conversation"),
      ),
      body: SafeArea(
          child: Column(
        children: [
          !receiversPhoneNumberSelected
              ? Row(
                  children: [
                    Text('To'),
                    SizedBox(width: 20),
                    Expanded(
                      child: Container(
                        child: TextField(
                          controller: phoneNumberController,
                          onChanged: (v) {
                            setState(() {
                              print('value: $v');
                              receiversPhoneNumber = v;
                            });
                          },
                          decoration: InputDecoration(
                            hintText: "Phone number",
                          ),
                          keyboardType: TextInputType.number,
                        ),
                      ),
                    )
                  ],
                )
              : Text('Messaging: $receiversPhoneNumber'),
          receiversPhoneNumber.isNotEmpty && !receiversPhoneNumberSelected
              ? Row(
                  children: [
                    Expanded(
                        child: Container(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Icon(Icons.phone),
                          Text(receiversPhoneNumber),
                          TextButton(
                            child: Text('Message',
                                style: kP1.copyWith(color: Colors.blueAccent)),
                            onPressed: () async {
                              DocumentSnapshot<Map<String, dynamic>>?
                                  currentConversation =
                                  await getCurrentConversation(
                                      receiversPhoneNumber,
                                      widget.usersPhoneNumber);
                              DocumentReference<Map<String, dynamic>>
                                  messagesRef = FirebaseFirestore.instance.doc(
                                      'messages/${currentConversation?.id}');
                              setState(() {
                                messages = messagesRef;
                                receiversPhoneNumberSelected = true;
                              });
                            },
                          )
                        ],
                      ),
                    ))
                  ],
                )
              : SizedBox.shrink(),
          FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
              future: FirebaseFirestore.instance
                  .doc(
                      "phone_numbers/${FirebaseAuth.instance.currentUser?.uid}")
                  .get(),
              builder: (context, future) {
                //TODO we should pass in the phone number to this page to ensure the
                // user can't reach this page without a phone number.

                if (!future.hasData)
                  return Center(
                    child:
                        Text('You need to add a phone number to your account.'),
                  );

                String userPhoneNumber = future.data?.data()?['phone_number'];
                return Expanded(
                    child: Container(
                  /// Retrieve messages for this conversation
                  child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                      stream: messages?.snapshots(),
                      builder: (context, messagesSnapshot) {
                        if (!messagesSnapshot.hasData) return SizedBox.shrink();
                        DocumentSnapshot<Map<String, dynamic>>? _doc =
                            messagesSnapshot.data;
                        List<MapEntry> messageEntries =
                            messagesSnapshot.data?.data()?.entries.toList() ??
                                [];

                        print(
                            'messagesSnapshot.data.data(): ${messagesSnapshot.data?.data()}');
                        Timestamp ts = Timestamp(1000, 10000);
                        ts.compareTo(ts);

                        /// Sort the messages by the created_at timestamp
                        messageEntries.sort((a, b) => a.value["created_at"]
                            .compareTo(b.value["created_at"]));

                        return Column(
                          children: [
                            Expanded(
                              child: Container(
                                  margin:
                                      EdgeInsets.symmetric(horizontal: 12.0),
                                  child: ListView(
                                    children: List.generate(
                                        messageEntries.length,
                                        (i) => MessageBubble(
                                            message: messageEntries[i].value,
                                            isUser: messageEntries[i]
                                                    .value['from'] ==
                                                userPhoneNumber)),
                                  )),
                            )
                          ],
                        );
                      }),
                ));
              }),
          Row(
            children: [
              IconButton(
                icon: Icon(
                  Icons.attach_file,
                  color: Colors.blue,
                ),
                onPressed: () {
                  ///Show Attachment Options
                  showModalBottomSheet<void>(
                    context: context,
                    backgroundColor: Colors.white.withOpacity(0.0),
                    builder: (BuildContext context) {
                      return Padding(
                        padding: EdgeInsets.all(12.0),
                        child: Column(
                          children: [
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10.0),
                                color: Colors.white.withOpacity(0.90),
                              ),
                              padding: EdgeInsets.all(8.0),
                              child: Column(
                                children: [
                                  Text('Add Media',
                                      style: kP3.copyWith(
                                          color: Colors.grey[700])),
                                  SizedBox(height: 18.0),
                                  Divider(
                                    thickness: 1.0,
                                  ),
                                  TextButton(
                                    child: Text(
                                      'Photo',
                                      style: kH4.copyWith(color: Colors.blue),
                                    ),
                                    onPressed: () {
                                      /// Implement Add Photo Feature
                                      print('add photo');
                                    },
                                  ),
                                  Divider(
                                    thickness: 1.0,
                                  ),
                                  TextButton(
                                    child: Text(
                                      'Video',
                                      style: kH4.copyWith(color: Colors.blue),
                                    ),
                                    onPressed: () {
                                      /// Implement Add Video Feature
                                      print('add video');
                                    },
                                  ),
                                  Divider(
                                    thickness: 1.0,
                                  ),
                                  TextButton(
                                    child: Text(
                                      'Audio',
                                      style: kH4.copyWith(color: Colors.blue),
                                    ),
                                    onPressed: () {
                                      /// Implement Add Audio Feature
                                      print('add audio');
                                    },
                                  ),
                                  Divider(
                                    thickness: 1.0,
                                  ),
                                  TextButton(
                                    child: Text(
                                      'Location',
                                      style: kH4.copyWith(color: Colors.blue),
                                    ),
                                    onPressed: () {
                                      /// Implement Add Location Feature
                                      print('add location');
                                    },
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(height: 8.0),
                            Row(
                              children: [
                                Expanded(
                                  child: Container(
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(10.0),
                                      color: Colors.white,
                                    ),
                                    child: TextButton(
                                      child: Text(
                                        'Cancel',
                                        style: kH4.copyWith(color: Colors.blue),
                                      ),
                                      onPressed: () {
                                        /// Close Dialog
                                        Navigator.pop(context);
                                      },
                                    ),
                                  ),
                                ),
                              ],
                            )
                          ],
                        ),
                      );
                    },
                  );
                },
              ),
              Expanded(
                child: Container(
                    child: TextField(
                  controller: messageController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                        borderSide: BorderSide(color: Colors.black38)),
                  ),
                )),
              ),
              IconButton(
                icon: Icon(Icons.send),
                onPressed: () async {
                  // Send message through Twilio from this User's Twilio Phone Number

                  //Validation logic to ensure a valid phone number and message before
                  //sending.

                  print('user phone num: ${widget.usersPhoneNumber}');
                  HttpsCallable callable = FirebaseFunctions.instance
                      .httpsCallable(
                          'twilioSendMessage',
                          options: HttpsCallableOptions(
                              timeout: Duration(seconds: 30)));
                  final HttpsCallableResult _result =
                      await callable.call(<String, String>{
                    'to': phoneNumberController.text,
                    'from': widget.usersPhoneNumber,
                    'body': messageController.text
                  });

                  if (_result.data['status'] == 'OK') {
                    Map _mapResult = _result.data as Map;
                    print('_result.data: $_mapResult');

                    ///Add message to database
                    Map message = {
                      "created_at": DateTime.now(),
                      "to": phoneNumberController.text,
                      "from": widget.usersPhoneNumber,
                      "body": messageController.text,
                      "sms_message_sid": _mapResult['message_sid'],
                    };

                    DocumentReference<Map<String, dynamic>>? docRef =
                        await addMessageToDatabase(message);
                    setState(() {
                      messages = docRef;
                    });
                    messageController.clear();
                  } else {
                    print('Request failed: ${_result.data}.');
                    //TODO deal with message send errors
                  }
                },
              )
            ],
          )
        ],
      )),
    );
  }
}
