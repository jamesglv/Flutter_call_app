import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/base_page.dart';
import 'package:messenger_app_flutter/components/custom_app_bar.dart';
import 'package:messenger_app_flutter/components/default_text_field.dart';
import 'package:messenger_app_flutter/components/message_bubble.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/utilities/twilio_services.dart';

class ConversationPage extends StatefulWidget {
  final DocumentReference conversationRef;
  final String otherUser;
  final String userNumber;
  ConversationPage(
      {Key? key, required this.otherUser, required this.conversationRef, required this.userNumber})

      : super(key: key);

  @override
  State<ConversationPage> createState() => _ConversationPageState();
}

class _ConversationPageState extends State<ConversationPage> {
  TextEditingController _messageController = TextEditingController();
  ScrollController _scrollController = new ScrollController();
  DocumentReference<Map<String, dynamic>>? messages;

  void _scrollDown() {
    _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
  }

  @override
  Widget build(BuildContext context) {
    double sH = MediaQuery.of(context).size.height;
    return Scaffold(
      body: SafeArea(
          child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Column(
          children: [
            CustomAppBar(
              backActionWidget: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Row(
                  children: [
                    Icon(
                      Icons.arrow_back_ios,
                      color: Colors.blue,
                    ),
                    Text(
                      'Messages',
                      style: kP1.copyWith(color: Colors.blue),
                    ),
                  ],
                ),
              ),
              title: Text(
                widget.otherUser,
                style: kP1Bold.copyWith(color: Colors.black),
              ),
            ),
            Expanded(
              child: Container(
                /// Retrieve messages for this conversation
                child: StreamBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                    stream: FirebaseFirestore.instance
                        .doc('messages/${widget.conversationRef.id}')
                        .snapshots(),
                    builder: (context, messagesSnapshot) {
                      if (!messagesSnapshot.hasData) return SizedBox.shrink();
                      List<MapEntry> messages =
                          messagesSnapshot.data?.data()?.entries.toList() ?? [];

                      Timestamp ts = Timestamp(1000, 10000);
                      ts.compareTo(ts);

                      /// Sort the messages by the created_at timestamp
                      messages.sort((a, b) => a.value["created_at"]
                          .compareTo(b.value["created_at"]));

                      return Column(
                        children: [
                          Expanded(
                            child: Container(
                                margin: EdgeInsets.symmetric(horizontal: 12.0),
                                child: ListView(
                                  children: List.generate(
                                      messages.length,
                                      (i) => MessageBubble(
                                          message: messages[i].value,
                                          isUser: messages[i].value['from'] ==
                                              widget.userNumber)),
                                )),
                          ),
                          Row(
                            children: [
                              IconButton(
                                icon: Icon(
                                  Icons.attach_file,
                                  color: Colors.blue,
                                ),
                                onPressed: () {
                                  ///Show Attachment Options
                                  showModalBottomSheet<void>(
                                    context: context,
                                    backgroundColor:
                                        Colors.white.withOpacity(0.0),
                                    builder: (BuildContext context) {
                                      return Padding(
                                        padding: EdgeInsets.all(12.0),
                                        child: Column(
                                          children: [
                                            Container(
                                              decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(10.0),
                                                color: Colors.white
                                                    .withOpacity(0.90),
                                              ),
                                              padding: EdgeInsets.all(8.0),
                                              child: Column(
                                                children: [
                                                  Text('Add Media',
                                                      style: kP3.copyWith(
                                                          color: Colors
                                                              .grey[700])),
                                                  SizedBox(height: 18.0),
                                                  Divider(
                                                    thickness: 1.0,
                                                  ),
                                                  TextButton(
                                                    child: Text(
                                                      'Photo',
                                                      style: kH4.copyWith(
                                                          color: Colors.blue),
                                                    ),
                                                    onPressed: () {
                                                      /// Implement Add Photo Feature
                                                      print('add photo');
                                                    },
                                                  ),
                                                  Divider(
                                                    thickness: 1.0,
                                                  ),
                                                  TextButton(
                                                    child: Text(
                                                      'Video',
                                                      style: kH4.copyWith(
                                                          color: Colors.blue),
                                                    ),
                                                    onPressed: () {
                                                      /// Implement Add Video Feature
                                                      print('add video');
                                                    },
                                                  ),
                                                  Divider(
                                                    thickness: 1.0,
                                                  ),
                                                  TextButton(
                                                    child: Text(
                                                      'Audio',
                                                      style: kH4.copyWith(
                                                          color: Colors.blue),
                                                    ),
                                                    onPressed: () {
                                                      /// Implement Add Audio Feature
                                                      print('add audio');
                                                    },
                                                  ),
                                                  Divider(
                                                    thickness: 1.0,
                                                  ),
                                                  TextButton(
                                                    child: Text(
                                                      'Location',
                                                      style: kH4.copyWith(
                                                          color: Colors.blue),
                                                    ),
                                                    onPressed: () {
                                                      /// Implement Add Location Feature
                                                      print('add location');
                                                    },
                                                  ),
                                                ],
                                              ),
                                            ),
                                            SizedBox(height: 8.0),
                                            Row(
                                              children: [
                                                Expanded(
                                                  child: Container(
                                                    decoration: BoxDecoration(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              10.0),
                                                      color: Colors.white,
                                                    ),
                                                    child: TextButton(
                                                      child: Text(
                                                        'Cancel',
                                                        style: kH4.copyWith(
                                                            color: Colors.blue),
                                                      ),
                                                      onPressed: () {
                                                        /// Close Dialog
                                                        Navigator.pop(context);
                                                      },
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            )
                                          ],
                                        ),
                                      );
                                    },
                                  );
                                },
                              ),

                              /// Message Text Field
                              Expanded(
                                child: Container(
                                  child: DefaultTextField(
                                      borderColor:
                                          Colors.white.withOpacity(0.0),
                                      focusedBorderColor:
                                          Colors.white.withOpacity(0.0),
                                      hintText: 'Aa',
                                      controller: _messageController,
                                      onChanged: (v) {
                                        if (v.isNotEmpty) setState(() {});
                                      }),
                                ),
                              ),
                              TextButton(
                                  onPressed: () async {

                                    String usersPhoneNumber = await FirebaseFirestore.instance
                                        .doc(
                                        'phone_numbers/${FirebaseAuth.instance.currentUser?.uid}')
                                        .get()
                                        .then((value) => value.data()?['phone_number']) ??
                                        "";
                                    print(usersPhoneNumber);
                                    print(widget.otherUser);

                                    // Send message through Twilio from this User's Twilio Phone Number

                                    //Validation logic to ensure a valid phone number and message before
                                    //sending.

                                    HttpsCallable callable = FirebaseFunctions.instance
                                        .httpsCallable(
                                        'twilioSendMessage',
                                        options: HttpsCallableOptions(
                                            timeout: Duration(seconds: 30)));
                                    final HttpsCallableResult _result =
                                    await callable.call(<String, String>{
                                      'to': widget.otherUser,
                                      'from': usersPhoneNumber,
                                      'body': _messageController.text
                                    });

                                    if (_result.data['status'] == 'OK') {
                                      Map _mapResult = _result.data as Map;
                                      print('_result.data: $_mapResult');

                                      ///Add message to database
                                      Map message = {
                                        "created_at": DateTime.now(),
                                        "to": widget.otherUser,
                                        "from": usersPhoneNumber,
                                        "body": _messageController.text,
                                        "sms_message_sid": _mapResult['message_sid'],
                                        "price": 0.0515,
                                      };

                                      DocumentReference<Map<String, dynamic>>? docRef =
                                      await addMessageToDatabase(message);
                                      setState(() {
                                        messages = docRef as List<MapEntry>;
                                      });
                                      _messageController.clear();
                                    } else {
                                      print('Request failed: ${_result.data}.');
                                      //TODO deal with message send errors
                                    }

                                    /*
                                    /// Update Firestore with the message.
                                    /// Message send is disabled until they
                                    /// have started typing the message.

                                    if (_messageController.text.isNotEmpty) {
                                      messagesSnapshot.data?.reference.update({
                                        "${DateTime.now().millisecondsSinceEpoch}":
                                            {
                                          "message": _messageController.text,
                                          "user": FirebaseAuth
                                              .instance.currentUser?.uid,
                                          "created_at": DateTime.now()
                                        }
                                      });
                                      _messageController.clear();

                                      ///Update Firestore conversation entry
                                      FirebaseFirestore.instance
                                      .collection('conversations')
                                      .doc('${messagesSnapshot.data?.reference}')
                                      .update({
                                        'last_message': _messageController.text,
                                        'last_modified': DateTime.now()
                                      });
                                    } */
                                  },
                                  child: Text(
                                    'send',
                                    style: kP2.copyWith(
                                        color:
                                            _messageController.text.isNotEmpty
                                                ? Colors.blue
                                                : Colors.blueGrey),
                                  ))
                            ],
                          )
                        ],
                      );
                    }),
              ),
            ),
          ],
        ),
      )),
    );
  }
}
