import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/custom_app_bar.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/utilities/twilio_services.dart';
import 'package:messenger_app_flutter/views/contacts/contacts.dart';
import 'package:messenger_app_flutter/views/profile/select_phone_number_page.dart';
import 'package:messenger_app_flutter/views/sign_in/login.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    String? _name = FirebaseAuth.instance.currentUser?.displayName ?? "";
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            CustomAppBar(),
            Expanded(
              child: Container(
                child: Padding(
                  padding: EdgeInsets.all(12.0),

                  /// Retrieve the user's profile
                  child: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                      future: FirebaseFirestore.instance
                          .collection('profiles')
                          .doc(FirebaseAuth.instance.currentUser?.uid)
                          .get(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData)
                          return Center(
                            child: Container(
                              child: CircularProgressIndicator(),
                            ),
                          );
                        Map<String, dynamic>? profile = snapshot.data?.data();
                        return ListView(
                          children: [
                            Text('Profile', style: kH1Bold),
                            Divider(thickness: 1.0),
                            Padding(
                                padding: EdgeInsets.symmetric(vertical: 12.0),
                                child: Text(
                                    profile != null
                                        ? "Hey ${profile['user_name']}"
                                        : "Name: ...",
                                    style: kP1)),
                            Divider(thickness: 1.0),
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: 12.0),
                              child: Text(
                                  "Email Address: ${FirebaseAuth.instance.currentUser?.email}",
                                  style: kP1),
                            ),
                            Divider(thickness: 1.0),
                            profile?['twilio_number'] == null
                                ? ElevatedButton(
                                    onPressed: () {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  SelectPhoneNumberPage(
                                                      profileRef: snapshot
                                                          .data?.reference)));
                                    },
                                    child: Text('Get Number'))
                                : Padding(
                                    padding:
                                        EdgeInsets.symmetric(vertical: 12.0),
                                    child: Text(
                                        "Account Phone Number: ${profile?['twilio_number']}",
                                        style: kP1),
                                  ),
                            Divider(thickness: 1.0),
                            TextButton(
                                onPressed: () {
                                  //FirebaseAuth.instance.signOut();
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => ContactsPage()));
                                },
                                child: Text(
                                  'Contacts',
                                  style: kP1.copyWith(color: Colors.blue),
                                )),
                            Divider(thickness: 1.0),
                            TextButton(
                                onPressed: () {
                                  FirebaseAuth.instance.signOut();
                                  Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => LoginPage()));
                                },
                                child: Text(
                                  'Log Out',
                                  style: kP1.copyWith(color: Colors.red),
                                )),
                            Divider(thickness: 1.0),
                          ],
                        );
                      }),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
