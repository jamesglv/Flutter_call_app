import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/custom_app_bar.dart';
import 'package:messenger_app_flutter/components/default_text_field.dart';
import 'package:messenger_app_flutter/components/full_width_button.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';

class CreateContact extends StatefulWidget {
  //String contactNumber;
  CreateContact({Key? key}) : super(key: key);

  @override
  State<CreateContact> createState() => _CreateContactState();
}

class _CreateContactState extends State<CreateContact> {
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _companyNameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _secondPhoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  bool waiting = false;

  @override
  Widget build(BuildContext context) {
    double sW = MediaQuery
        .of(context)
        .size
        .width;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(8.0),
          child: Column(
            children: [
              CustomAppBar(
                backActionWidget: GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Row(
                    children: [
                      SizedBox(width: 10),
                      Icon(
                        Icons.arrow_back_ios,
                        color: Colors.blue,
                      ),
                      Text(
                        'Back',
                        style: kP1.copyWith(color: Colors.blue),
                      ),
                    ],
                  ),
                ),
                title: Text(
                  'New Contact',
                  style: kH4Bold,
                ),
              ),

              SizedBox(height: 20),

              /// First Name Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "First Name",
                  controller: _firstNameController,
                  onChanged: (t) {},
                ),
              ),

              /// Last Name Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Last Name",
                  controller: _lastNameController,
                  onChanged: (t) {},
                ),
              ),

              /// Company Name Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Company Name",
                  controller: _companyNameController,
                  onChanged: (t) {},
                ),
              ),

              /// Phone Number Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Primary Phone",
                  controller: _phoneNumberController,
                  onChanged: (t) {},
                ),
              ),

              /// Company Name Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Secondary Phone",
                  controller: _secondPhoneController,
                  onChanged: (t) {},
                ),
              ),

              /// Email Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 8.0),
                child: DefaultTextField(
                  hintText: "Email Address",
                  controller: _emailController,
                  onChanged: (t) {},
                ),
              ),

              /// Login Button
              FullWidthButton(
                  child: Text(
                    'Save Contact',
                    style: kP1WhiteBold,
                  ),
                  onPressed: (){
                    FirebaseFirestore.instance
                        .collection('contacts')
                        .doc()
                        .set({
                      "contact_owner": FirebaseAuth.instance.currentUser?.uid,
                      "full_name": _firstNameController.text + " " + _lastNameController.text,
                      "first_name": _firstNameController.text,
                      "last_name": _lastNameController.text,
                      "company_name": _companyNameController.text,
                      "phone_number": _phoneNumberController.text,
                      "second_phone_number": _secondPhoneController.text,
                      "email": _emailController.text
                    });

                    _firstNameController.clear();
                    _lastNameController.clear();
                    _companyNameController.clear();
                    _phoneNumberController.clear();
                    _secondPhoneController.clear();
                    _emailController.clear();

                    Navigator.pop(context);

                  }, //TODO onPressed add to contacts database
                  waiting: waiting)
            ],
          ),
        ),
      ),
    );
  }
}
