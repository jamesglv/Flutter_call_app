import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/custom_app_bar.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/utilities/firestore_services.dart';
import 'package:messenger_app_flutter/utilities/twilio_services.dart';
import 'package:messenger_app_flutter/views/contacts/contacts.dart';
import 'package:messenger_app_flutter/views/contacts/edit_contact.dart';
import 'package:messenger_app_flutter/views/profile/select_phone_number_page.dart';
import 'package:messenger_app_flutter/views/sign_in/login.dart';

class ContactDetailPage extends StatelessWidget {
  final DocumentReference contactRef;
  const ContactDetailPage(
      {Key? key, required this.contactRef}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            CustomAppBar(
              backActionWidget: GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Row(
                  children: [
                    SizedBox(width: 10),
                    Icon(
                      Icons.arrow_back_ios,
                      color: Colors.blue,
                    ),
                    Text(
                      'Back',
                      style: kP1.copyWith(color: Colors.blue),
                    ),
                    SizedBox(height: 15)
                  ],
                ),
              ),
              actionWidget: TextButton(
                onPressed: () {
                  print(contactRef.id);
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => EditContact(contactRef: contactRef,
                          )));
                }, 
                child: Text("edit"),
              ),
            ),
            Expanded(
              child: Container(
                child: Padding(
                  padding: EdgeInsets.all(12.0),

                  /// Retrieve the user's profile
                  child: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                      future: FirebaseFirestore.instance
                          .collection('contacts')
                          .doc(contactRef.id)
                          .get(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData)
                          return Center(
                            child: Container(
                              child: CircularProgressIndicator(),
                            ),
                          );
                        Map<String, dynamic>? contact = snapshot.data?.data();
                        return ListView(
                          children: [
                            SizedBox(
                              child:
                                  Column(
                                    children: [
                                      Text(
                                          contact != null
                                              ? '${contact['full_name']}'
                                              : "No Name",
                                          style: kH1Bold
                                      ),
                                    ],
                                  ),
                            ),
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: 10),
                              child: Column(
                                children: [
                                  if(contact!['company_name'].length > 0)
                                    Text(
                                      "${contact!['company_name']}",
                                      style: TextStyle(fontSize: 18),
                                    ),
                                ],
                              ),
                            ),
                            Padding(padding: EdgeInsets.symmetric(vertical: 12.0),
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Color.fromRGBO(230, 230, 230, 1) ,
                                      foregroundColor: Color.fromRGBO(53, 121, 246, 1),
                                      elevation: 0,
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(15.0)),
                                      minimumSize: Size(84, 50),
                                      maximumSize: Size(84, 50), //////// HERE
                                    ),
                                    onPressed: (){
                                      //getConversation(uid1: contact!['phone_number'], uid2: getCurrentUserNumber()); //TODO Else create new conversation
                                    },
                                    child: Column(
                                      children: [
                                        SizedBox(height: 8),
                                        Icon(Icons.chat_bubble,
                                            size: 22),
                                        Text(
                                          "message",
                                          style: TextStyle(fontSize: 12),
                                        )
                                      ],
                                    ),
                                  ),
                                  SizedBox(width: 10),
                                  ElevatedButton(
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Color.fromRGBO(230, 230, 230, 1) ,
                                      foregroundColor: Color.fromRGBO(53, 121, 246, 1),
                                      elevation: 0,
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(15.0)),
                                      minimumSize: Size(84, 50),
                                      maximumSize: Size(84, 50), //////// HERE
                                    ),
                                    onPressed: (){},
                                    child: Column(
                                      children: [
                                        SizedBox(height: 5),
                                        Icon(Icons.phone),
                                        Text(
                                            "call",
                                            style: TextStyle(fontSize: 12)
                                        )
                                      ],
                                    ),
                                  ),
                                ],
                              ),),
                            if (contact!['phone_number'].length > 0)
                              Column(
                                children: [
                                  Divider(thickness: 1.0),
                                  Padding(
                                    padding: EdgeInsets.symmetric(vertical: 12.0),
                                    child: Text(
                                        "Primary Phone: ${contact!['phone_number']}" ?? "Add Number",
                                        style: kP1),
                                  ),
                                ],
                              ),
                            if (contact!['second_phone_number'].length > 0)
                              Column(
                                children: [
                                  Divider(thickness: 1.0),
                                  Padding(
                                    padding: EdgeInsets.symmetric(vertical: 12.0),
                                    child: Text(
                                        "Second Phone: ${contact!['second_phone_number']}" ?? "Add Number",
                                        style: kP1),
                                  ),
                                ],
                              ),
                            if (contact!['email'].length > 0)
                              Column(
                                children: [
                                  Divider(thickness: 1.0),
                                  Padding(
                                    padding: EdgeInsets.symmetric(vertical: 12.0),
                                    child: Text(
                                        "Email: ${contact!['email']}" ?? "Add Email",
                                        style: kP1),
                                  ),
                                ],
                              ),

                            Divider(thickness: 1.0),


                          ],
                        );
                      }),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

