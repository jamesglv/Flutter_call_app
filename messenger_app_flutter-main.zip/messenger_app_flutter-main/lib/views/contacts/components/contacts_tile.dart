import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/base_page.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/utilities/date_time_helpers.dart';
import 'package:messenger_app_flutter/views/calls/call_page.dart';
import 'package:messenger_app_flutter/views/messages/conversation_page.dart';
import 'package:messenger_app_flutter/utilities/twilio_services.dart';
import 'package:messenger_app_flutter/views/messages/messages_page.dart';

import '../contacts_page.dart';

class ContactTile extends StatelessWidget {
  final DocumentReference contactRef;
  final String contactName;
  const ContactTile(
      {Key? key,
        required this.contactRef,
        required this.contactName})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
        future: FirebaseFirestore.instance.doc('contacts/${contactRef.id}').get(),
        builder: (context, future) {

          return GestureDetector(
              onTap: () async {
                // String contactName = await FirebaseFirestore.instance
                //     .doc(
                //     'contacts/${FirebaseAuth.instance.currentUser?.uid}')
                //     .get()
                //     .then((value) => value.data()?['phone_number']) ??
                //     "";
                if (contactRef != null) {
                  /// Navigate to the Contact Page, set BasePage to the
                  /// Calls Page (id: 0)
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => BasePage(
                              id: 0,
                              ui: ContactDetailPage(
                                contactRef: contactRef,

                              ),)));
                }
              },
              child: Container(
                  margin: EdgeInsets.all(0.0),
                  padding: EdgeInsets.all(15.0),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        width: 1,
                        color: Colors.grey.shade300,
                      ),
                    ),
                  ),
                  //   borderRadius: BorderRadius.circular(12.0)),
                  //alignment: Alignment.centerLeft,
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Text(
                                contactName,
                                style: kH4,
                                textAlign: TextAlign.left,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  )));
        });
  }
}
