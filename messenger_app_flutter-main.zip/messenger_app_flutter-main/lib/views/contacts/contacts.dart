import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/views/contacts/components/contacts_tile.dart';
import 'package:messenger_app_flutter/views/contacts/create_contact.dart';
import 'package:messenger_app_flutter/components/custom_app_bar.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';




class ContactsPage extends StatelessWidget {
  const ContactsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
          child: Column(
            children: [
              CustomAppBar(
                backActionWidget: GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Row(
                    children: [
                      SizedBox(width: 10),
                      Icon(
                        Icons.arrow_back_ios,
                        color: Colors.blue,
                      ),
                      Text(
                        'Back',
                        style: kP1.copyWith(color: Colors.blue),
                      ),
                    ],
                  ),
                ),
                actionWidget: IconButton(
                  icon: Icon(Icons.add),
                  onPressed: () async {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => CreateContact(
                            )));
                  },

                ),
              ),
              Text('Contacts', style: kH1Bold),
              Expanded(
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 12.0),

                    child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(

                      /// Get a stream of contacts owned by current user
                        stream: FirebaseFirestore.instance
                            .collection('contacts')
                            .where('contact_owner',
                            isEqualTo: FirebaseAuth.instance.currentUser?.uid) //TODO query for current users number
                            .snapshots(),
                        builder: (context, snapshot) {
                          if (!snapshot.hasData)
                            return Center(
                              child: Container(child: CircularProgressIndicator()),
                            );
                          List<DocumentSnapshot<Map<String, dynamic>>> _contacts =
                              snapshot.data?.docs ?? [];
                          return ListView(
                            children: List.generate(_contacts.length, (i) {

                              DocumentReference? _contactRef =
                                  _contacts[i].reference;
                              Map _contact = _contacts[i].data() ?? {};
                              String contactName = _contact["full_name"];

                              return ContactTile(
                                  contactRef: _contactRef,
                                  contactName: contactName);
                            }),
                          );
                        }),
                  ))
            ],
          )),
    );
  }
}