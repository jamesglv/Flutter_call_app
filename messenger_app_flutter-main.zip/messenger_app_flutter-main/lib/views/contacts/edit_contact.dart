import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/custom_app_bar.dart';
import 'package:messenger_app_flutter/components/default_text_field.dart';
import 'package:messenger_app_flutter/components/full_width_button.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';

class EditContact extends StatefulWidget {
  DocumentReference contactRef;
  EditContact({Key? key, required this.contactRef}) : super(key: key);

  @override
  State<EditContact> createState() => _EditContactState();
}

class _EditContactState extends State<EditContact> {
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _companyNameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _secondPhoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();


  bool waiting = false;

  @override
  Widget build(BuildContext context) {
    double sW = MediaQuery
        .of(context)
        .size
        .width;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(8.0),
          child: Column(
            children: [
              CustomAppBar(
                backActionWidget: GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Row(
                    children: [
                      SizedBox(width: 10),
                      Icon(
                        Icons.arrow_back_ios,
                        color: Colors.blue,
                      ),
                      Text(
                        'Back',
                        style: kP1.copyWith(color: Colors.blue),
                      ),
                    ],
                  ),
                ),
                title: Text(
                  'New Contact',
                  style: kH4Bold,
                ),
              ),

              SizedBox(height: 20),

              Expanded(
                child: Container(
                  child: Padding(
                    padding: EdgeInsets.all(12.0),

                    /// Retrieve the user's profile
                    child: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                        future: FirebaseFirestore.instance
                            .collection('contacts')
                            .doc(widget.contactRef.id)
                            .get(),
                        builder: (context, snapshot) {
                          if (!snapshot.hasData)
                            return Center(
                              child: Container(
                                child: CircularProgressIndicator(),
                              ),
                            );
                          Map<String, dynamic>? contact = snapshot.data?.data();
                          return ListView(
                            children: [
                              SizedBox(
                                child:
                                Column(
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                                      child:
                                      DefaultTextField(
                                        hintText: "First Name",
                                        controller: _firstNameController,
                                        onChanged: (t) {},
                                      ),
                                    ),
                                    TextFormField(
                                      initialValue: contact!['first_name'],
                                      decoration: const InputDecoration(
                                          hintText: "First Name"
                                      ),
                                      controller: _firstNameController,
                                    ),
                                    // TextFormField(
                                    //   initialValue: contact!['last_name'] ?? "",
                                    //   decoration: const InputDecoration(
                                    //       hintText: "Last Name"
                                    //   ),
                                    //   controller: _lastNameController,
                                    // ),
                                    Text(
                                        contact != null
                                            ? '${contact['full_name']}'
                                            : "No Name",
                                        style: kH1Bold
                                    ),
                                  ],
                                ),
                              ),

                              Padding(padding: EdgeInsets.symmetric(vertical: 12.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Color.fromRGBO(230, 230, 230, 1) ,
                                        foregroundColor: Color.fromRGBO(53, 121, 246, 1),
                                        elevation: 0,
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(15.0)),
                                        minimumSize: Size(84, 50),
                                        maximumSize: Size(84, 50), //////// HERE
                                      ),
                                      onPressed: (){
                                        //getConversation(uid1: contact!['phone_number'], uid2: getCurrentUserNumber()); //TODO Else create new conversation
                                      },
                                      child: Column(
                                        children: [
                                          SizedBox(height: 8),
                                          Icon(Icons.chat_bubble,
                                              size: 22),
                                          Text(
                                            "message",
                                            style: TextStyle(fontSize: 12),
                                          )
                                        ],
                                      ),
                                    ),
                                    SizedBox(width: 10),
                                    ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Color.fromRGBO(230, 230, 230, 1) ,
                                        foregroundColor: Color.fromRGBO(53, 121, 246, 1),
                                        elevation: 0,
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(15.0)),
                                        minimumSize: Size(84, 50),
                                        maximumSize: Size(84, 50), //////// HERE
                                      ),
                                      onPressed: (){},
                                      child: Column(
                                        children: [
                                          SizedBox(height: 5),
                                          Icon(Icons.phone),
                                          Text(
                                              "call",
                                              style: TextStyle(fontSize: 12)
                                          )
                                        ],
                                      ),
                                    ),
                                  ],
                                ),),
                              if (contact!['phone_number'].length > 0)
                                Column(
                                  children: [
                                    Divider(thickness: 1.0),
                                    Padding(
                                      padding: EdgeInsets.symmetric(vertical: 12.0),
                                      child: Text(
                                          "Primary Phone: ${contact!['phone_number']}" ?? "Add Number",
                                          style: kP1),
                                    ),
                                  ],
                                ),
                              if (contact!['second_phone_number'].length > 0)
                                Column(
                                  children: [
                                    Divider(thickness: 1.0),
                                    Padding(
                                      padding: EdgeInsets.symmetric(vertical: 12.0),
                                      child: Text(
                                          "Second Phone: ${contact!['second_phone_number']}" ?? "Add Number",
                                          style: kP1),
                                    ),
                                  ],
                                ),
                              if (contact!['email'].length > 0)
                                Column(
                                  children: [
                                    Divider(thickness: 1.0),
                                    Padding(
                                      padding: EdgeInsets.symmetric(vertical: 12.0),
                                      child: Text(
                                          "Email: ${contact!['email']}" ?? "Add Email",
                                          style: kP1),
                                    ),
                                  ],
                                ),

                              Divider(thickness: 1.0),


                            ],
                          );
                        }),
                  ),
                ),
              ),


              /// First Name Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "First Name",
                  controller: _firstNameController,
                  onChanged: (t) {},
                ),
              ),

              /// Last Name Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Last Name",
                  controller: _lastNameController,
                  onChanged: (t) {},
                ),
              ),

              /// Company Name Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Company Name",
                  controller: _companyNameController,
                  onChanged: (t) {},
                ),
              ),

              /// Phone Number Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Primary Phone",
                  controller: _phoneNumberController,
                  onChanged: (t) {},
                ),
              ),

              /// Company Name Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Secondary Phone",
                  controller: _secondPhoneController,
                  onChanged: (t) {},
                ),
              ),

              /// Email Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 8.0),
                child: DefaultTextField(
                  hintText: "Email Address",
                  controller: _emailController,
                  onChanged: (t) {},
                ),
              ),

              /// Login Button
              FullWidthButton(
                  child: Text(
                    'Save Contact',
                    style: kP1WhiteBold,
                  ),
                  onPressed: (){
                    FirebaseFirestore.instance
                        .collection('contacts')
                        .doc()
                        .set({
                      "contact_owner": FirebaseAuth.instance.currentUser?.uid,
                      "full_name": _firstNameController.text + " " + _lastNameController.text,
                      "first_name": _firstNameController.text,
                      "last_name": _lastNameController.text,
                      "company_name": _companyNameController.text,
                      "phone_number": _phoneNumberController.text,
                      "second_phone_number": _secondPhoneController.text,
                      "email": _emailController.text
                    });

                    _firstNameController.clear();
                    _lastNameController.clear();
                    _companyNameController.clear();
                    _phoneNumberController.clear();
                    _secondPhoneController.clear();
                    _emailController.clear();

                    Navigator.pop(context);

                  }, //TODO onPressed add to contacts database
                  waiting: waiting)
            ],
          ),
        ),
      ),
    );
  }
}




/*
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/custom_app_bar.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/utilities/firestore_services.dart';
import 'package:messenger_app_flutter/utilities/twilio_services.dart';
import 'package:messenger_app_flutter/views/contacts/contacts.dart';
import 'package:messenger_app_flutter/views/profile/select_phone_number_page.dart';
import 'package:messenger_app_flutter/views/sign_in/login.dart';

import '../../components/default_text_field.dart';
import '../../components/full_width_button.dart';

class EditContact extends StatefulWidget {
  final DocumentReference contactRef;
  const EditContact({Key? key, required this.contactRef}) : super(key: key);

  @override
  State<EditContact> createState() => _EditContactState();
}

class _EditContactState extends State<EditContact> {
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _companyNameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _secondPhoneController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  bool waiting = false;

  @override
  Widget build(BuildContext context) {
    double sW = MediaQuery
        .of(context)
        .size
        .width;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(8.0),
          child: Column(
            children: [
              CustomAppBar(
                backActionWidget: GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Row(
                    children: [
                      SizedBox(width: 10),
                      Icon(
                        Icons.arrow_back_ios,
                        color: Colors.blue,
                      ),
                      Text(
                        'Back',
                        style: kP1.copyWith(color: Colors.blue),
                      ),
                    ],
                  ),
                ),
                title: Text(
                  'Edit Contact',
                  style: kH4Bold,
                ),
              ),

              SizedBox(height: 20),

              Expanded(
                child: Container(
                  child: Padding(
                    padding: EdgeInsets.all(12.0),

                    /// Retrieve the user's profile
                    child: FutureBuilder<DocumentSnapshot<Map<String, dynamic>>>(
                        future: FirebaseFirestore.instance
                            .collection('contacts')
                            .doc(widget.contactRef.id)
                            .get(),
                        builder: (context, snapshot) {
                          if (!snapshot.hasData)
                            return Center(
                              child: Container(
                                child: CircularProgressIndicator(),
                              ),
                            );
                          Map<String, dynamic>? contact = snapshot.data?.data();
                          return ListView(
                            children: [
                              SizedBox(
                                child:
                                Column(
                                  children: [
                                    // Padding(
                                    //   padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                                    //   child: DefaultTextField(
                                    //     initialValue: contact!['first_name'],
                                    //     hintText: "First Name",
                                    //     controller: _firstNameController,
                                    //     onChanged: (t) {},
                                    //   ),
                                    // ),
                                    TextFormField(
                                        initialValue: contact!['first_name'],
                                        decoration: const InputDecoration(
                                            hintText: "First Name"
                                        ),
                                        controller: _firstNameController,
                                      ),
                                    // TextFormField(
                                    //   initialValue: contact!['last_name'] ?? "",
                                    //   decoration: const InputDecoration(
                                    //       hintText: "Last Name"
                                    //   ),
                                    //   controller: _lastNameController,
                                    // ),
                                    Text(
                                        contact != null
                                            ? '${contact['full_name']}'
                                            : "No Name",
                                        style: kH1Bold
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(vertical: 10),
                                child: Column(
                                  children: [
                                    if(contact!['company_name'].length > 0)
                                      Text(
                                        "${contact!['company_name']}",
                                        style: TextStyle(fontSize: 18),
                                      ),
                                  ],
                                ),
                              ),
                              Padding(padding: EdgeInsets.symmetric(vertical: 12.0),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Color.fromRGBO(230, 230, 230, 1) ,
                                        foregroundColor: Color.fromRGBO(53, 121, 246, 1),
                                        elevation: 0,
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(15.0)),
                                        minimumSize: Size(84, 50),
                                        maximumSize: Size(84, 50), //////// HERE
                                      ),
                                      onPressed: (){
                                        //getConversation(uid1: contact!['phone_number'], uid2: getCurrentUserNumber()); //TODO Else create new conversation
                                      },
                                      child: Column(
                                        children: [
                                          SizedBox(height: 8),
                                          Icon(Icons.chat_bubble,
                                              size: 22),
                                          Text(
                                            "message",
                                            style: TextStyle(fontSize: 12),
                                          )
                                        ],
                                      ),
                                    ),
                                    SizedBox(width: 10),
                                    ElevatedButton(
                                      style: ElevatedButton.styleFrom(
                                        backgroundColor: Color.fromRGBO(230, 230, 230, 1) ,
                                        foregroundColor: Color.fromRGBO(53, 121, 246, 1),
                                        elevation: 0,
                                        shape: RoundedRectangleBorder(
                                            borderRadius: BorderRadius.circular(15.0)),
                                        minimumSize: Size(84, 50),
                                        maximumSize: Size(84, 50), //////// HERE
                                      ),
                                      onPressed: (){},
                                      child: Column(
                                        children: [
                                          SizedBox(height: 5),
                                          Icon(Icons.phone),
                                          Text(
                                              "call",
                                              style: TextStyle(fontSize: 12)
                                          )
                                        ],
                                      ),
                                    ),
                                  ],
                                ),),
                              if (contact!['phone_number'].length > 0)
                                Column(
                                  children: [
                                    Divider(thickness: 1.0),
                                    Padding(
                                      padding: EdgeInsets.symmetric(vertical: 12.0),
                                      child: Text(
                                          "Primary Phone: ${contact!['phone_number']}" ?? "Add Number",
                                          style: kP1),
                                    ),
                                  ],
                                ),
                              if (contact!['second_phone_number'].length > 0)
                                Column(
                                  children: [
                                    Divider(thickness: 1.0),
                                    Padding(
                                      padding: EdgeInsets.symmetric(vertical: 12.0),
                                      child: Text(
                                          "Second Phone: ${contact!['second_phone_number']}" ?? "Add Number",
                                          style: kP1),
                                    ),
                                  ],
                                ),
                              if (contact!['email'].length > 0)
                                Column(
                                  children: [
                                    Divider(thickness: 1.0),
                                    Padding(
                                      padding: EdgeInsets.symmetric(vertical: 12.0),
                                      child: Text(
                                          "Email: ${contact!['email']}" ?? "Add Email",
                                          style: kP1),
                                    ),
                                  ],
                                ),

                              Divider(thickness: 1.0),


                            ],
                          );
                        }),
                  ),
                ),
              ),


              /*
              Expanded(
                  child: child),
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: TextFormField(
                  initialValue: "Name",
                  decoration: const InputDecoration(
                    hintText: "First Name"
                  ),
                  // controller: _firstNameController,
                  // onChanged: (t) {},
                ),
              ),
              /// First Name Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "First Name",
                  controller: _firstNameController,
                  onChanged: (t) {},
                ),
              ),

              /// Last Name Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Last Name",
                  controller: _lastNameController,
                  onChanged: (t) {},
                ),
              ),

              /// Company Name Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Company Name",
                  controller: _companyNameController,
                  onChanged: (t) {},
                ),
              ),

              /// Phone Number Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Primary Phone",
                  controller: _phoneNumberController,
                  onChanged: (t) {},
                ),
              ),

              /// Company Name Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Secondary Phone",
                  controller: _secondPhoneController,
                  onChanged: (t) {},
                ),
              ),

              /// Email Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 8.0),
                child: DefaultTextField(
                  hintText: "Email Address",
                  controller: _emailController,
                  onChanged: (t) {},
                ),
              ),

              /// Login Button
              FullWidthButton(
                  child: Text(
                    'Save Contact',
                    style: kP1WhiteBold,
                  ),
                  onPressed: (){
                    FirebaseFirestore.instance
                        .doc(widget.contactRef.id)
                        .update({
                      "contact_owner": FirebaseAuth.instance.currentUser?.uid,
                      "full_name": _firstNameController.text + " " + _lastNameController.text,
                      "first_name": _firstNameController.text,
                      "last_name": _lastNameController.text,
                      "company_name": _companyNameController.text,
                      "phone_number": _phoneNumberController.text,
                      "second_phone_number": _secondPhoneController.text,
                      "email": _emailController.text
                    });

                    _firstNameController.clear();
                    _lastNameController.clear();
                    _companyNameController.clear();
                    _phoneNumberController.clear();
                    _secondPhoneController.clear();
                    _emailController.clear();

                    Navigator.pop(context);

                  }, //TODO onPressed add to contacts database
                  waiting: waiting)
              */
            ],
          ),
        ),
      ),
    );
  }
}
*/