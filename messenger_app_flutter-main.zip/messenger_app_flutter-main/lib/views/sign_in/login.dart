import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/base_page.dart';
import 'package:messenger_app_flutter/components/custom_app_bar.dart';
import 'package:messenger_app_flutter/components/default_text_field.dart';
import 'package:messenger_app_flutter/components/full_width_button.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/views/sign_in/sign_up_page.dart';

class LoginPage extends StatefulWidget {
  LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool waiting = false;

  @override
  Widget build(BuildContext context) {
    double sW = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(8.0),
          child: Column(
            children: [
              CustomAppBar(
                actionWidget: TextButton(
                    onPressed: () {
                      // Go to Login Page
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => SignUpPage()));
                    },
                    child: Text(
                      'Sign Up',
                      style: kP1Bold.copyWith(color: Colors.blue),
                    )),
                title: Text(
                  'Log In',
                  style: kH4.copyWith(color: Colors.black),
                ),
              ),

              /// App Logo
              Container(
                  margin: EdgeInsets.all(24.0),
                  width: sW * 0.35,
                  child: Image.asset('assets/images/messenger_logo.png')),

              /// Email Address Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Email Address",
                  controller: _emailController,
                  onChanged: (t) {},
                ),
              ),

              /// Password Field
              Padding(
                padding: EdgeInsets.all(8.0),
                child: DefaultTextField(
                  hintText: "Password",
                  controller: _passwordController,
                  onChanged: (t) {},
                  password: true,
                ),
              ),

              /// Login Button
              FullWidthButton(
                  child: Text(
                    'Log In',
                    style: kP1WhiteBold,
                  ),
                  onPressed: login,
                  waiting: waiting)
            ],
          ),
        ),
      ),
    );
  }

  void login() async {
    setState(() {
      waiting = true;
    });
    UserCredential _userCred =
        await FirebaseAuth.instance.signInWithEmailAndPassword(
      email: _emailController.text,
      password: _passwordController.text,
    );

    if (_userCred != null) {
      Navigator.pushReplacement(
          context,
          MaterialPageRoute(
              builder: (context) => BasePage(id: 0))); // Messages(Home)
    } else {
      /// No user returned. Check for errors. Display
      /// any errors to the user.
      setState(() {
        waiting = false;
      });
    }
  }
}
