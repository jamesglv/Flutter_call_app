import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/base_page.dart';
import 'package:messenger_app_flutter/components/custom_app_bar.dart';
import 'package:messenger_app_flutter/components/default_text_field.dart';
import 'package:messenger_app_flutter/components/full_width_button.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/utilities/twilio_services.dart';
import 'package:messenger_app_flutter/utilities/user_name_search_field_service.dart';
import 'package:messenger_app_flutter/views/sign_in/login.dart';

class SignUpPage extends StatefulWidget {
  SignUpPage({Key? key}) : super(key: key);

  @override
  State<SignUpPage> createState() => _SignUpPageState();
}

class _SignUpPageState extends State<SignUpPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _firstNameController = TextEditingController();
  final TextEditingController _lastNameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  bool waiting = false;
  String _emailError = '';
  String _firstNameError = '';
  String _lastNameError = '';
  String _passwordError = '';

  bool validData() {
    bool isValid = true;

    List<TextEditingController> controllersToValidate = [
      _emailController,
      _firstNameController,
      _lastNameController,
      _passwordController,
    ];

    for (int i = 0; i < controllersToValidate.length; i++) {
      if (controllersToValidate[i].text.isEmpty) {
        isValid = false;
        setState(() {
          switch (i) {
            case 0:
              _emailError = '*required';
              break;
            case 1:
              _firstNameError = '*required';
              break;
            case 2:
              _lastNameError = '*required';
              break;
            case 3:
              _passwordError = '*required';
              break;
          }
        });
      } else {
        setState(() {
          switch (i) {
            case 0:
              _emailError = '';
              break;
            case 1:
              _firstNameError = '';
              break;
            case 2:
              _lastNameError = '';
              break;
            case 3:
              _passwordError = '';
              break;
          }
        });
      }
    }
    return isValid;
  }

  @override
  Widget build(BuildContext context) {
    double sW = MediaQuery.of(context).size.width;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              CustomAppBar(
                backActionWidget: TextButton(
                    onPressed: () {
                      // Go to Login Page
                      Navigator.pushReplacement(context,
                          MaterialPageRoute(builder: (context) => LoginPage()));
                    },
                    child: Row(
                      children: [
                        Icon(
                          Icons.arrow_back_ios,
                          color: Colors.blue,
                        ),
                        Text(
                          'Log In',
                          style: kP1Bold.copyWith(color: Colors.blue),
                        ),
                      ],
                    )),
                title: Text(
                  'Sign Up',
                  style: kH4.copyWith(color: Colors.black),
                ),
              ),

              /// App Logo
              Container(
                  margin: EdgeInsets.all(24.0),
                  width: sW * 0.35,
                  child: Image.asset('assets/images/messenger_logo.png')),

              /// Email Field
              Padding(
                padding: EdgeInsets.fromLTRB(8.0, 8.0, 8.0, 0.0),
                child: DefaultTextField(
                  hintText: "Email Address",
                  errorText: _emailError,
                  controller: _emailController,
                  onChanged: (t) {},
                ),
              ),

              /// Password Field
              Padding(
                padding: EdgeInsets.all(8.0),
                child: DefaultTextField(
                  hintText: "Password",
                  errorText: _passwordError,
                  controller: _passwordController,
                  onChanged: (t) {},
                  password: true,
                ),
              ),

              /// First Name Field
              Padding(
                padding: EdgeInsets.all(8.0),
                child: DefaultTextField(
                  hintText: "First Name",
                  errorText: _firstNameError,
                  controller: _firstNameController,
                  onChanged: (t) {},
                ),
              ),

              /// Last Name Field
              Padding(
                padding: EdgeInsets.all(8.0),
                child: DefaultTextField(
                  hintText: "Last Name",
                  errorText: _lastNameError,
                  controller: _lastNameController,
                  onChanged: (t) {},
                ),
              ),

              /// Sign Up Button
              FullWidthButton(
                  child: Text(
                    'Sign Up',
                    style: kP1WhiteBold,
                  ),
                  onPressed: signUp,
                  waiting: waiting)
            ],
          ),
        ),
      ),
    );
  }

  void signUp() async {
    setState(() {
      waiting = true;
    });

    /// Check if data is valid.
    if (validData()) {
      print('data is valid');

      /// Create a New User Account
      UserCredential _userCred =
          await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailController.text,
        password: _passwordController.text,
      );

      print('userCred returned');

      /// Add a Profile in Firestore if User has been successfully created
      if (_userCred.user != null) {
        print('_userCred.user: ${_userCred.user}');
        String displayName = _firstNameController.text +
            (_lastNameController.text.isNotEmpty
                ? (" " + _lastNameController.text)
                : '');

        /// Get a number from Twilio
        List? twilioNumbers = await getAvailableNumbers();
        print('twilioNumbers[0][friendlyName]: ${twilioNumbers[0]['mobile']}');
        Map result =
            await assignPhoneNumber(phoneNumber: twilioNumbers[0]['mobile']);

        await FirebaseFirestore.instance
            .doc("phone_numbers/${_userCred.user?.uid}")
            .set({
          "friendly_name": result['friendly_name'],
          "phone_number": result['phone_number'],
          "sid": result['sid'],
          "sms_url": result['sms_url'],
          "status": result['status'],
          "uri": result['uri'],
        });

        /// Create a user profile in Firestore.
        /// Note - need to add the User Agreement / Privacy Policy checkbox once
        /// those have been created.
        FirebaseFirestore.instance
            .collection('profiles')
            .doc(_userCred.user?.uid)
            .set({
          'accepted_user_agreement': DateTime.now(),
          'user_name': displayName,
          'user_name_search': createUserNameSearchField(userName: displayName),
          'twilio_number': result['phone_number']
        }).then((_) {
          setState(() {
            waiting = false;
          });
        });

        /// Create billing collection in Firestore
        FirebaseFirestore.instance
            .collection('billing')
            .doc(_userCred.user?.uid)
            .set({
          'sign_up_date': DateTime.now(),
          'region': "AU"
        }).then((_) {
          setState(() {
            waiting = false;
          });
        });

        /// Navigate to the Messages (Home)
        Navigator.pushReplacement(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    BasePage(id: 0))); // Send to Home / Messages
      } else {
        /// No user returned. Check for errors. Display
        /// any errors to the user.
        /// Note - need to implement error message(s) to the user

        setState(() {
          waiting = false;
        });
      }
    } else {
      /// Data not valid. Display
      /// any errors to the user.
      /// Note - need to implement error message(s) to the user

      setState(() {
        waiting = false;
      });
    }
  }
}
