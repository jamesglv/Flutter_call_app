import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:messenger_app_flutter/components/base_page.dart';
import 'package:messenger_app_flutter/views/sign_in/login.dart';

class LandingPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.active) {
          User? user = snapshot.data;

          if (user == null) {
            return LoginPage();
          }

          /// BasePage is a template with bottom navigation bar. ID 0 is home /
          /// messages page.
          return BasePage(id: 0);
        } else {
          /// Show a loading indicator while the app establishes a connection
          /// with Firebase Auth
          return Scaffold(
            body: Column(
              children: [
                Center(
                  child: Container(child: CircularProgressIndicator()),
                ),
              ],
            ),
          );
        }
      },
    );
  }
}
