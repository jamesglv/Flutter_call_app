import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/custom_app_bar.dart';
import 'package:messenger_app_flutter/components/user_search_bar.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/utilities/twilio_services.dart';
import 'package:messenger_app_flutter/views/messages/components/conversation_tile.dart';
import 'package:messenger_app_flutter/views/messages/new_conversation_page.dart';
import 'package:messenger_app_flutter/views/calls/new_call_page.dart';

class CallsPage extends StatelessWidget {

  const CallsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double sH = MediaQuery.of(context).size.height;
    return Scaffold(
      body: SafeArea(
          child: Column(
            children: [
              CustomAppBar(
                actionWidget: IconButton(
                  icon: Icon(Icons.edit_note_outlined),
                  onPressed: () async {
                    String usersPhoneNumber = await FirebaseFirestore.instance
                        .doc(
                        'phone_numbers/${FirebaseAuth.instance.currentUser?.uid}')
                        .get()
                        .then((value) => value.data()?['phone_number']) ??
                        "";
                    if (usersPhoneNumber.isNotEmpty) {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => NewConversationPage(
                                  usersPhoneNumber: usersPhoneNumber)));
                    } else {
                      //TODO implement code to direct user to select a phone number before sending messages
                    }
                  },
                ),
              ),
              Text('Phone', style: kH1Bold),
              Expanded(
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 12.0),
                    child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(

                      /// Get a stream of conversations where the user is a member of
                      /// of the conversation
                        stream: FirebaseFirestore.instance
                            .collection('conversations')
                            .where('members',
                            arrayContains: '+61482076870') //TODO Array contains users phone number
                            .snapshots(),
                        builder: (context, snapshot) {
                          if (!snapshot.hasData)
                            return Center(
                              child: Container(child: CircularProgressIndicator()),
                            );
                          List<DocumentSnapshot<Map<String, dynamic>>> _conversations =
                              snapshot.data?.docs ?? [];
                          return ListView(
                            children: List.generate(_conversations.length, (i) {
                              /// Currently we assume only two individuals are
                              /// in a conversation

                              DocumentReference? _conversationRef =
                                  _conversations[i].reference;
                              Map _conversation = _conversations[i].data() ?? {};
                              String uid = FirebaseAuth.instance.currentUser?.uid ?? '';
                              String otherUser = _conversation["members"][0] != uid
                                  ? _conversation["members"][0]
                                  : _conversation["members"][1];

                              /// We need to query Firestore for the other user's
                              /// profile information so we can display the
                              /// user's name and phone number.
                              return ConversationTile(
                                  conversationReference: _conversationRef,
                                  otherUserId: otherUser);
                            }),
                          );
                        }),
                  ))
            ],
          )),
    );
  }
}
