import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/base_page.dart';
import 'package:messenger_app_flutter/components/dial_pad.dart';

class NewCall extends StatelessWidget {
  const NewCall({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double sH = MediaQuery.of(context).size.height;
    return Scaffold(
      body: SafeArea(
        child: Container(
          child: DialPad(),
          alignment: Alignment.center,
        ),

      ),
    );
  }
}
