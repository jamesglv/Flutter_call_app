import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/custom_app_bar.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/views/messages/components/conversation_tile.dart';

class RecentCallsPage extends StatelessWidget {
  const RecentCallsPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double sH = MediaQuery.of(context).size.height;
    return Scaffold(
      body: SafeArea(
          child: Column(
            children: [
              CustomAppBar(
                backActionWidget: GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Row(
                    children: [
                      SizedBox(width: 10),
                      Icon(
                        Icons.arrow_back_ios,
                        color: Colors.blue,
                      ),
                      Text(
                        'Back',
                        style: kP1.copyWith(color: Colors.blue),
                      ),
                    ],
                  ),
                ),

              ),
              Text('Recent Calls', style: kH1Bold),
              Expanded(
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 12.0),

                    child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(

                      /// Get a stream of conversations where the user is a member of
                      /// of the conversation
                        stream: FirebaseFirestore.instance
                            .collection('conversations')
                            .where('profiles',
                            arrayContains: "+61482076870") //TODO query for current users number
                            .snapshots(),
                        builder: (context, snapshot) {
                          if (!snapshot.hasData)
                            return Center(
                              child: Container(child: CircularProgressIndicator()),
                            );
                          List<DocumentSnapshot<Map<String, dynamic>>> _conversations =
                              snapshot.data?.docs ?? [];
                          return ListView(
                            children: List.generate(_conversations.length, (i) {
                              /// Currently we assume only two individuals are
                              /// in a conversation

                              DocumentReference? _conversationRef =
                                  _conversations[i].reference;
                              Map _conversation = _conversations[i].data() ?? {};
                              String uid = FirebaseAuth.instance.currentUser?.uid ?? '';
                              String otherUser = _conversation["members"][0] != uid
                                  ? _conversation["members"][0]
                                  : _conversation["members"][1];

                              /// We need to query Firestore for the other user's
                              /// profile information so we can display the
                              /// user's name and phone number.
                              return ConversationTile(
                                  conversationReference: _conversationRef,
                                  otherUserId: otherUser);
                            }),
                          );
                        }),
                  ))
            ],
          )),
    );
  }
}
