import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/views/sign_in/login.dart';

class CustomAppBar extends StatelessWidget {
  final Widget? actionWidget;
  final Function? actionOnTap;
  final Widget? backActionWidget;
  final Function? backActionOnTap;
  final Widget? title;
  CustomAppBar(
      {Key? key,
      this.actionWidget,
      this.actionOnTap,
      this.backActionWidget,
      this.backActionOnTap,
      this.title})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Container(
              child: Row(
            children: [backActionWidget ?? SizedBox.shrink()],
          )),
        ),
        title ?? SizedBox(height: 18.0),
        Expanded(
            child: Container(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              actionWidget ?? SizedBox.shrink(),
            ],
          ),
        ))
      ],
    );
  }
}
