import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';

class FullWidthButton extends StatelessWidget {
  final Widget child;
  final Function onPressed;
  final bool waiting;
  const FullWidthButton(
      {Key? key,
      required this.child,
      required this.onPressed,
      required this.waiting})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Expanded(
          child: Container(
            margin: EdgeInsets.symmetric(horizontal: 8.0),
            child: !waiting
                ? ElevatedButton(
                    onPressed: () {
                      onPressed();
                    },
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 12.0),
                      child: child,
                    ),
                    style: defaultButtonStyle)
                : Center(
                    child: CircularProgressIndicator(),
                  ),
          ),
        ),
      ],
    );
  }
}
