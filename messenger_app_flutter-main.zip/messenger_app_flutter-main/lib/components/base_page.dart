import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/views/messages/messages_page.dart';
import 'package:messenger_app_flutter/views/calls/new_call_page.dart';
import 'package:messenger_app_flutter/views/profile_page.dart';

class BasePage extends StatefulWidget {
  final bool gradientBackground;
  final int id;
  final Widget? ui;
  BasePage({this.gradientBackground = true, required this.id, this.ui});

  @override
  State<BasePage> createState() => _BasePageState();
}

class _BasePageState extends State<BasePage> {
  Widget _getUi(int index) {
    switch (index) {
      case 0:

        /// Home/Messages
        return MessagesPage();
      case 1:

        /// Profile
        return NewCall();
      case 2:

      /// Profile
        return ProfilePage();
      default:

        /// Default to Home/Messages
        return MessagesPage();
    }
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
      _ui = _getUi(index);
    });
  }

  int? _selectedIndex;
  Widget _ui = MessagesPage(); // Default to Messages (Home)

  @override
  void initState() {
    /// Executed before the screen is displayed.
    super.initState();
    _selectedIndex = widget.id;

    /// If a UI is passed as a parameter, display the passed in UI. Otherwise,
    /// set the UI based on the ID passed in.
    /// ID will determine which Bottom Navigator item is selected.
    _ui = widget.ui ?? _getUi(widget.id);
  }

  @override
  Widget build(BuildContext context) {
    double sw = MediaQuery.of(context).size.width;
    return Scaffold(
      body: _ui,
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(
              icon: Icon(CupertinoIcons.bubble_left), label: "Messages"),
          BottomNavigationBarItem(
              icon: Icon(CupertinoIcons.phone), label: "Calls"),
          BottomNavigationBarItem(
              icon: Icon(Icons.account_circle), label: "Profile"),
        ],
        currentIndex: _selectedIndex ?? 0,
        selectedItemColor: Color(0xFF0C0068),
        unselectedItemColor: Colors.blueGrey[200],
        onTap: _onItemTapped,
      ),
    );
  }
}
