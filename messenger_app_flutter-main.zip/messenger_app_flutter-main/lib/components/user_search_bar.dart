import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/components/base_page.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/utilities/firestore_services.dart';
import 'package:messenger_app_flutter/views/messages/conversation_page.dart';

class UserNameSearchBar extends StatefulWidget {
  final Function callback;

  UserNameSearchBar({required this.callback});

  @override
  _UserNameSearchBarState createState() => _UserNameSearchBarState();
}

class _UserNameSearchBarState extends State<UserNameSearchBar> {
  TextEditingController _searchController = TextEditingController();
  String _searchQuery = "";

  void clearSearchResults() {
    setState(() {
      _searchController.clear();
      _searchQuery = "";
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: Container(
                child: TextFormField(
                  controller: _searchController,
                  decoration: InputDecoration(
                      hintText: "Search",
                      enabledBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.blueGrey.shade400),
                      ),
                      focusedBorder: UnderlineInputBorder(
                        borderSide: BorderSide(color: Colors.blueGrey.shade500),
                      ),
                      prefixIcon: Icon(
                        Icons.search_rounded,
                        color: Colors.grey[800],
                      ),
                      fillColor: Colors.grey[200],
                      filled: true),
                  onChanged: (val) {
                    setState(() {
                      _searchQuery = val.toLowerCase();
                    });
                  },
                ),
              ),
            ),
            TextButton(
                child: const Text('Cancel'),
                onPressed: () {
                  widget.callback("close me");
                }),
          ],
        ),
        FutureBuilder<QuerySnapshot?>(
          future: _searchQuery != null
              ? FirebaseFirestore.instance
                  .collection('profiles')
                  .where("user_name_search", arrayContains: _searchQuery)
                  .limit(5)
                  .get()
              : null,
          builder: (context, snapshot) {
            List data = snapshot.data?.docs ?? [];
            if (!snapshot.hasData || data.isEmpty) {
              return _searchQuery.isNotEmpty
                  ? Center(
                      child: Container(
                          margin: EdgeInsets.all(1.0),
                          child: CircularProgressIndicator()),
                    )
                  : Container();
            }

            List<Widget> _widgetList = [];
            for (DocumentSnapshot<Map<String, dynamic>> user in data) {
              if (user.id != FirebaseAuth.instance.currentUser?.uid) {
                try {
                  _widgetList.add(GestureDetector(
                    onTap: () async {
                      String usersPhoneNumber = await FirebaseFirestore.instance
                          .doc(
                          'phone_numbers/${FirebaseAuth.instance.currentUser?.uid}')
                          .get()
                          .then((value) => value.data()?['phone_number']) ??
                          "";
                      /// Before we create a new conversation, we want to check if
                      /// this user already has a chat started with this individual

                      /// Step 1: Search for conversations with both users
                      /// Currently we only return the first converation, but in
                      /// future we could add additional UI that allows the user
                      /// to select which converation they want to enter if more
                      /// than one result is returned
                      String uid1 =
                          FirebaseAuth.instance.currentUser?.uid ?? '';
                      String uid2 = user.id;

                      /// If no conversation reference is returned, then create
                      /// a new conversation.
                      DocumentReference conversationRef =
                          await getConversation(
                                  uid1: uid1, uid2: uid2) ??
                              await startNewConversation(
                                  uid1: uid1, uid2: uid2);

                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => BasePage(
                                  id: 0,
                                  ui: ConversationPage(
                                      conversationRef: conversationRef,
                                      otherUser: uid2,
                                      userNumber: usersPhoneNumber,
                                  ))));
                    },
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          user.data()?['user_name'],
                          style: kH1Bold,
                        ),
                        Divider(thickness: 1.0),
                      ],
                    ),
                  ));
                } catch (e, s) {
                  print(s);
                }
              }
            }
            return Padding(
              padding: EdgeInsets.only(top: 12.0),
              child: Column(
                children: _widgetList,
              ),
            );
          },
        ),
      ],
    );
  }
}
