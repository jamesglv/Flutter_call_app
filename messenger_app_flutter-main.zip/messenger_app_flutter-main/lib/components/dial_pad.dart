import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:messenger_app_flutter/utilities/twilio_call_services.dart';
import 'package:messenger_app_flutter/views/calls/recent_calls.dart';
import 'package:messenger_app_flutter/views/contacts/contacts.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/views/contacts/create_contact.dart';

import '../utilities/twilio_services.dart';
import 'custom_app_bar.dart';

class DialPad extends StatefulWidget {

  @override
  _DialPadState createState() => _DialPadState();
}

class _DialPadState extends State<DialPad> {
  //static const callChannel = MethodChannel('com.jamesogilvie.Messenger.messengerAppFlutter/call');

  var inputNumber = "";

  @override
  Widget build(BuildContext context) {
    double sH = MediaQuery
        .of(context)
        .size
        .height;
    return Scaffold(
      body: SafeArea(
          child: Column(
            children: [
              CustomAppBar(
                actionWidget: TextButton(
                  onPressed: () async {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => ContactsPage()));
                  },
                  child: Text("Contacts "),
                ),
              ),
              Column(
                children: [
                  SizedBox(height: 20),
                  Text(
                    inputNumber,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 30),
                  ),
                  if(inputNumber.isNotEmpty) //TODO use stateful widget visibility + animated fade
                  TextButton(
                      onPressed: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => CreateContact()));
                      },
                    child: Text("Add Contact") ),
                  if(inputNumber.isEmpty)
                    SizedBox(height: 48),

                  SizedBox(height: 40),
                ],
              ),
              Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          setState(() {
                            inputNumber = inputNumber + "1";
                            print(inputNumber);
                          });
                        },
                        child: Column(
                          children: [
                            Text(
                              '1',
                              style: TextStyle(
                                  fontSize: 28,
                                  color: Colors.black),
                            ),
                            Text(
                              '',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black
                              ),
                            )
                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          setState(() {
                            inputNumber = inputNumber + "2";
                            print(inputNumber);
                          });
                        },
                        child: Column(
                          children: [
                            Text(
                              '2',
                              style: TextStyle(
                                  fontSize: 28,
                                  color: Colors.black),
                            ),
                            Text(
                              'ABC',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black
                              ),
                            )
                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          setState(() {
                            inputNumber = inputNumber + "3";
                            print(inputNumber);
                          });
                        },
                        child: Column(
                          children: [
                            Text(
                              '3',
                              style: TextStyle(
                                  fontSize: 28,
                                  color: Colors.black),
                            ),
                            Text(
                              'DEF',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black
                              ),
                            )
                          ],
                        ),
                      ),

                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          setState(() {
                            inputNumber = inputNumber + "4";
                            print(inputNumber);
                          });
                        },
                        child: Column(
                          children: [
                            Text(
                              '4',
                              style: TextStyle(
                                  fontSize: 28,
                                  color: Colors.black),
                            ),
                            Text(
                              'GHI',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black
                              ),
                            )
                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          setState(() {
                            inputNumber = inputNumber + "5";
                            print(inputNumber);
                          });
                        },
                        child: Column(
                          children: [
                            Text(
                              '5',
                              style: TextStyle(
                                  fontSize: 28,
                                  color: Colors.black),
                            ),
                            Text(
                              'JKL',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black
                              ),
                            )
                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          setState(() {
                            inputNumber = inputNumber + "6";
                            print(inputNumber);
                          });
                        },
                        child: Column(
                          children: [
                            Text(
                              '6',
                              style: TextStyle(
                                  fontSize: 28,
                                  color: Colors.black),
                            ),
                            Text(
                              'MNO',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black
                              ),
                            )
                          ],
                        ),
                      ),

                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          setState(() {
                            inputNumber = inputNumber + "7";
                            print(inputNumber);
                          });
                        },
                        child: Column(
                          children: [
                            Text(
                              '7',
                              style: TextStyle(
                                  fontSize: 28,
                                  color: Colors.black),
                            ),
                            Text(
                              'PQRS',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black
                              ),
                            )
                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          setState(() {
                            inputNumber = inputNumber + "8";
                            print(inputNumber);
                          });
                        },
                        child: Column(
                          children: [
                            Text(
                              '8',
                              style: TextStyle(
                                  fontSize: 28,
                                  color: Colors.black),
                            ),
                            Text(
                              'TUV',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black
                              ),
                            )
                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          setState(() {
                            inputNumber = inputNumber + "9";
                            print(inputNumber);
                          });
                        },
                        child: Column(
                          children: [
                            Text(
                              '9',
                              style: TextStyle(
                                  fontSize: 28,
                                  color: Colors.black),
                            ),
                            Text(
                              'WXYZ',
                              style: TextStyle(
                                  fontSize: 12,
                                  color: Colors.black
                              ),
                            )
                          ],
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          setState(() {
                            inputNumber = inputNumber + "*";
                            print(inputNumber);
                          });
                        },
                        child: Column(
                          children: [
                            Text(
                              '*',
                              style: TextStyle(
                                  fontSize: 35,
                                  color: Colors.black),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          setState(() {
                            inputNumber = inputNumber + "0";
                            print(inputNumber);
                          });
                        },
                        onLongPress: () {
                          setState(() {
                            inputNumber = inputNumber + "+";
                            print(inputNumber);
                          });
                        },
                        child: Column(
                          children: [
                            Text(
                                '0',
                                style: TextStyle(
                                    fontSize: 28,
                                    color: Colors.black),
                            ),
                            Text(
                              '+',
                              style: TextStyle(
                                  fontSize: 15,
                                  color: Colors.black
                              ),
                            )
                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          setState(() {
                            inputNumber = inputNumber + "#";
                            print(inputNumber);
                          });
                        },
                        child: Text(
                          '#',
                          style: TextStyle(
                            fontSize: 22,
                              color: Colors.black
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => RecentCallsPage()));
                        },
                        child: Column(
                          children: [
                            Icon(Icons.access_time_outlined,
                            size: 30),

                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(100, 200, 100, 1) ,
                          foregroundColor: Colors.white,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () async {
                          var token = await fetchToken();
                          print(token);
                          //makeCall(callTo: inputNumber, callFrom: '+61482076870'); //TODO callFrom userNum
                        },
                        child: Column(
                          children: [
                            Icon(Icons.phone),

                          ],
                        ),
                      ),
                      SizedBox(width: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Color.fromRGBO(229, 229, 229, 1),
                          foregroundColor: Colors.black,
                          elevation: 0,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(35.0)),
                          minimumSize: Size(70, 70), //////// HERE
                        ),
                        onPressed: () {
                          if(inputNumber.isNotEmpty){
                            setState(() {
                              inputNumber =
                                  inputNumber.substring(0, inputNumber.length - 1);
                              print(inputNumber);
                            });
                          } else {}
                        },
                        onLongPress: () {
                          setState(() {
                            inputNumber = "";
                          });
                        },
                        child: Column(
                          children: [
                            Icon(Icons.backspace_outlined,
                            size: 25),

                          ],
                        ),
                      ),

                    ],
                  ),
                ],
              ),
            ],
          )),
    );
  }
  // Future makeOutboundCall() async {
  //   await callChannel.invokeMethod('makeOutboundCall');
  // }
}
