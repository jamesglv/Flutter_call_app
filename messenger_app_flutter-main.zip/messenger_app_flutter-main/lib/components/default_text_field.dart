import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../utilities/constants.dart';

class DefaultTextField extends StatelessWidget {
  final Color? borderColor;
  final TextEditingController controller;
  final TextStyle? counterStyle;
  final String? errorText;
  final Color? focusedBorderColor;
  final bool? filled;
  final String? hintText;
  final String? initialValue;
  final TextStyle? hintStyle;
  final TextInputType? keyboardType;
  final int? minLines;
  final int? maxLines;
  final int? maxLength;
  final void Function(String) onChanged;
  final bool? password;
  final Color? textColor;

  DefaultTextField(
      {required this.hintText,
      this.initialValue,
      this.borderColor,
      required this.controller,
      this.counterStyle,
      this.errorText,
      this.focusedBorderColor,
      this.hintStyle,
      this.filled,
      this.keyboardType,
      this.minLines,
      this.maxLines,
      this.maxLength,
      required this.onChanged,
      this.password,
      this.textColor});

  @override
  Widget build(BuildContext context) {
    double screenWidth = MediaQuery.of(context).size.width;

    return Container(
      width: screenWidth,
      child: TextFormField(
        initialValue: initialValue,
        enableSuggestions: false,
        controller: controller,
        decoration: InputDecoration(
          counterStyle: counterStyle,
          fillColor: Colors.white,
          filled: filled ?? false,
          enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide:
                  BorderSide(color: borderColor ?? Colors.blueGrey.shade300)),
          focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide(color: focusedBorderColor ?? Colors.blue)),
          errorStyle: (errorText ?? "").isNotEmpty
              ? kP3.apply(color: Colors.red)
              : null,
          errorText: (errorText ?? "").isNotEmpty ? errorText : null,
          hintText: hintText,
          hintStyle: hintStyle ?? kP1.apply(color: Colors.grey[500]),
        ),
        keyboardType: keyboardType,
        minLines: minLines ?? 1,
        maxLines: maxLines ?? 1,
        maxLength: maxLength,
        maxLengthEnforcement:
            maxLength != null ? MaxLengthEnforcement.enforced : null,
        onChanged: onChanged,
        obscureText: password ?? false,
        style: TextStyle(color: textColor ?? Colors.grey[900]),
      ),
    );
  }
}
