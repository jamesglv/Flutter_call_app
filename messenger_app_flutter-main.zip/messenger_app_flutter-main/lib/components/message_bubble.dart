import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:messenger_app_flutter/utilities/constants.dart';
import 'package:messenger_app_flutter/utilities/date_time_helpers.dart';

class MessageBubble extends StatelessWidget {
  final bool isUser;
  final Map message;
  const MessageBubble({required this.message, required this.isUser});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          isUser ? Expanded(child: Container()) : SizedBox.shrink(),
          Expanded(
            child: Container(
              child: Column(
                crossAxisAlignment:
                    isUser ? CrossAxisAlignment.end : CrossAxisAlignment.start,
                children: [
                  Container(
                    child:
                        Text(message['body'], style: isUser ? kP2White : kP2),
                    margin: EdgeInsets.symmetric(vertical: 3.0),
                    padding: EdgeInsets.all(12.0),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(isUser ? 10 : 0),
                          topRight: Radius.circular(isUser ? 0 : 10),
                          bottomLeft: Radius.circular(10),
                          bottomRight: Radius.circular(10)),
                      boxShadow: [
                        BoxShadow(
                          blurRadius: 1.0,
                          color: Colors.black26,
                          offset: Offset(1, 1),
                        )
                      ],
                      color: isUser ? Colors.blue : Colors.white,
                    ),
                  ),
                  Text(
                    longFormatDate(message["created_at"]),
                    style: kP3.copyWith(color: Colors.grey),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
