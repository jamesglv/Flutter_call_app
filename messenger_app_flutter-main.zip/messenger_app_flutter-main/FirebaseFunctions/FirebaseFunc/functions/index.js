const functions = require("firebase-functions");
const admin = require("firebase-admin");
const { firestore } = require("firebase-admin");

//Twilio
const AccountSID = "AC9161e2b64c4aa8c0d24b8a66fcb081b5";
const AuthToken = "9863a1e4758051a39473cdf9d3ff5373";
const client = require('twilio')(AccountSID, AuthToken);


admin.initializeApp();


// Currently creating new conversation each time, does not recognise existing conversation. Messages documents are not being set in Firestore.

///Append inbound text messages to Firestore conversation based on sender and recipient number.
exports.inboundSMS = functions.https.onRequest(async(req, res) => {

    let senderNum = req.body["From"];
    let recipientNum = req.body["To"];
    let params;
    let textBody = req.body["Body"];

    if (Object.keys(req.query).length === 0) {
        params = req.body;
        
        /// Query Firestore for UserID that matches recipient number
        var recipientNumQuery = await admin.firestore().collection('profiles')
        .where('twilio_number', '==', recipientNum)
        .get().then(result => {
            result.forEach((doc) => {
                var recipientUID = doc.id;

                /// Query Firestore for Conversation ID that contains both recipientNum and senderNum
                var conversationsQuery = admin.firestore().collection('conversations')
                .where('members','array-contains-any', //not recognising existing conversation
                    [
                        [recipientNum, senderNum],
                        [senderNum, recipientNum]
                    ])
                .get().then(result => {
                    
                    /// If conversation exists
                    /// Append to Messages
                    if (result  && result.length > 0) {
                        result.forEach((document) => {
                        
                            var conversationID = document.id;
                            var currentTime = Date.now()
                            
                            const messagesEntry = {};
                            messagesEntry[currentTime] = {
                                    "message": textBody,
                                    "user": senderNum,
                                    "created_at": DateTime.now()
                            }

                            admin.firestore().collection('messages').doc(`${conversationID}`).set({
                                messagesEntry
                            });
                            
        
                        })
                    } else {
                        ////If conversation does not exist
                        ///Create New Conversation

                        var newConversationID = admin.firestore().collection('conversations').doc();
                        newConversationID.set({
                            "created_at": Date(),
                            "members": {
                                recipientNum, senderNum
                            }
                        });
                        
                        ///Then add message - currently not setting the messages to Firestore.
                        let currentTime = Date.now();
                        
                        const messagesEntry = {};
                        messagesEntry[`${currentTime}`] = {
                                "message": textBody,
                                "user": senderNum,
                                "created_at": DateTime.now()
                        };

                        admin.firestore().collection('messages').doc(`${newConversationID.id}`).set({
                            messagesEntry
                        });
                    }
                });
            });
        });


    } else {
        params = req.query;
    }

    res.sendStatus(200);
});


/// Send webhook to Twilio to create new subaccount with user email
exports.createSubAccount = functions.https.onRequest(async(req, res) => {

    client.api.v2010.accounts
                .create({friendlyName: res.body["userEmail"]})
                .then(account => {

                    console.log(account.sid)
                
                });
});


/// Assign user a Twilio number
exports.assignUserNumber = functions.https.onRequest(async (req, res) => {

    const userEmail = res.body["userEmail"];
    const region = res.body["region"];

    /// Query subaccounts by friendlyname
    client.api.v2010.accounts
                .list({friendlyName: userEmail, limit: 1})
                .then(accounts => accounts.forEach(a => {
                    
                    const subSID = a.sid;
                    const subAuthToken = a.authToken;
                    const subClient = require('twilio')(subSID, subAuthToken);

                    /// Query available mobile numbers by region
                    subClient.availablePhoneNumbers(region)
                        .mobile
                        .list({limit: 1})
                        .then(mobile => mobile.forEach(m => {
        
                            console.log(m.friendlyName);

                            /// Assign phone number for subaccount
                            client.incomingPhoneNumbers
                            .create({phoneNumber: m.friendlyName})
                            .then(incoming_phone_number => {

                                console.log(incoming_phone_number.sid)

                                /// Append to Firestore Profiles Collection
                                admin.firestore().collection('profiles').doc(`${userEmail}`).set({
                                    messagesEntry
                                });
                            });
                        }));

                }));

});